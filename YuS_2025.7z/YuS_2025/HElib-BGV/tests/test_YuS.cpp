#include <iostream>
#include <filesystem>
#include <vector>
#include <array>
#include <atomic>
#include <cmath>
#include <chrono>
#include <fstream>
#include <memory>
#include <random>
#include <climits>
#include <cassert>

#include <NTL/ZZX.h>
#include <helib/helib.h>
#include <helib/ArgMap.h>
#include <helib/DoubleCRT.h>

#include "helib/CModulus.h"
#include "helib/powerful.h"
#include <immintrin.h>

#include "../Symmetric/Yus_p.hpp"
#include "../utils/tool.hpp"

using namespace std;
using namespace helib;
using namespace NTL;

/************************************************************************
  long p;          // plaintext primeplain_mod;
  long m;          // m-th cyclotomic polynomial
  long r;          // Lifting [defualt = 1]
  long bits;       // bits in the ciphertext modulus chain
  long c;          // columns in the key-switching matrix [default=2]
  long d;          // Degree of the field extension [default=1]
  long k;          // Security parameter [default=80]
  long s;          // Minimum number of slots [default=0]
************************************************************************/

//!!!!!!!!!!!!!!!!
constexpr unsigned BlockWords = 36;
constexpr unsigned BlockPlainWords = 24;
constexpr double TruncRate = BlockPlainWords / (double)BlockWords;

constexpr unsigned Nr = 6; // round number
constexpr long idx = 0;

constexpr tuple<long, long, long, long> paramMap[1][1] = {
    {
        // Nr = 4
        // {p, log2(m), bits, c}
        {65537, 16, 330, 3}, // 0 *
    }};

constexpr long log2Para_m = get<1>(paramMap[0][idx]) - 0;
constexpr long Para_p = get<0>(paramMap[0][idx]);    // plaintext prime
constexpr long Para_m = 1 << log2Para_m;             // cyclotomic polynomial
constexpr long phi_m = Para_m >> 1;                  // phi(m)
constexpr long Para_bits = get<2>(paramMap[0][idx]); // bits in the ciphertext modulus chain
constexpr long Para_c = get<3>(paramMap[0][idx]);    // columns in the key-switching matrix
constexpr long Para_r = 1;                           // Lifting [defualt = 1]
//!!!!!!!!!!!!!!!
constexpr long nslots = phi_m;
constexpr unsigned PlainBlock = nslots - 0;

constexpr unsigned int log2_constexpr(unsigned long long n, unsigned int p = 0)
{
    return (n <= 1) ? p : log2_constexpr(n / 2, p + 1);
}
constexpr long PlainMod = Para_p;
constexpr unsigned Wordbits = log2_constexpr(PlainMod - 1) + 1;
constexpr unsigned NrBlockWords = BlockWords * (Nr + 1);
constexpr long KeyStreamWords = BlockWords * PlainBlock;
constexpr long PlainWords = BlockPlainWords * PlainBlock;
constexpr long Plainbits = Wordbits * PlainWords;

constexpr long max_prime_size = (1ULL << (Wordbits - 1)) - 1;

constexpr unsigned NonceSize = 64;
constexpr long counter_begin = 0;
constexpr long counter_end = PlainBlock + counter_begin - 1;

YusP yusP(PlainMod);

// Linear transformation
void HE_M(vector<Ctxt> &eData)
{
    vector<Ctxt> temp = eData;
    Ctxt temp0_1 = temp[0];
    temp0_1 += temp[1];
    Ctxt temp0_2 = temp[0];
    temp0_2 += temp[2];
    Ctxt temp0_3 = temp[0];
    temp0_3 += temp[3];
    Ctxt temp1_2 = temp[1];
    temp1_2 += temp[2];
    Ctxt temp1_3 = temp[1];
    temp1_3 += temp[3];
    Ctxt temp2_3 = temp[2];
    temp2_3 += temp[3];
    Ctxt temp0_1_2 = temp0_1;
    temp0_1_2 += temp[2];
    Ctxt temp0_1_3 = temp0_1;
    temp0_1_3 += temp[3];
    Ctxt temp0_2_3 = temp0_2;
    temp0_2_3 += temp[3];
    Ctxt temp1_2_3 = temp1_2;
    temp1_2_3 += temp[3];
    Ctxt temp0_1_2_3 = temp0_1_2;
    temp0_1_2_3 += temp[3];
    Ctxt temp4_5 = temp[4];
    temp4_5 += temp[5];
    Ctxt temp4_6 = temp[4];
    temp4_6 += temp[6];
    Ctxt temp4_7 = temp[4];
    temp4_7 += temp[7];
    Ctxt temp5_6 = temp[5];
    temp5_6 += temp[6];
    Ctxt temp5_7 = temp[5];
    temp5_7 += temp[7];
    Ctxt temp6_7 = temp[6];
    temp6_7 += temp[7];
    Ctxt temp4_5_6 = temp4_5;
    temp4_5_6 += temp[6];
    Ctxt temp4_5_7 = temp4_5;
    temp4_5_7 += temp[7];
    Ctxt temp4_6_7 = temp4_6;
    temp4_6_7 += temp[7];
    Ctxt temp5_6_7 = temp5_6;
    temp5_6_7 += temp[7];
    Ctxt temp4_5_6_7 = temp4_5_6;
    temp4_5_6_7 += temp[7];
    Ctxt temp8_9 = temp[8];
    temp8_9 += temp[9];
    Ctxt temp8_10 = temp[8];
    temp8_10 += temp[10];
    Ctxt temp8_11 = temp[8];
    temp8_11 += temp[11];
    Ctxt temp9_10 = temp[9];
    temp9_10 += temp[10];
    Ctxt temp9_11 = temp[9];
    temp9_11 += temp[11];
    Ctxt temp10_11 = temp[10];
    temp10_11 += temp[11];
    Ctxt temp8_9_10 = temp8_9;
    temp8_9_10 += temp[10];
    Ctxt temp8_9_11 = temp8_9;
    temp8_9_11 += temp[11];
    Ctxt temp8_10_11 = temp8_10;
    temp8_10_11 += temp[11];
    Ctxt temp9_10_11 = temp9_10;
    temp9_10_11 += temp[11];
    Ctxt temp8_9_10_11 = temp8_9_10;
    temp8_9_10_11 += temp[11];
    Ctxt temp12_13 = temp[12];
    temp12_13 += temp[13];
    Ctxt temp12_14 = temp[12];
    temp12_14 += temp[14];
    Ctxt temp12_15 = temp[12];
    temp12_15 += temp[15];
    Ctxt temp13_14 = temp[13];
    temp13_14 += temp[14];
    Ctxt temp13_15 = temp[13];
    temp13_15 += temp[15];
    Ctxt temp14_15 = temp[14];
    temp14_15 += temp[15];
    Ctxt temp12_13_14 = temp12_13;
    temp12_13_14 += temp[14];
    Ctxt temp12_13_15 = temp12_13;
    temp12_13_15 += temp[15];
    Ctxt temp12_14_15 = temp12_14;
    temp12_14_15 += temp[15];
    Ctxt temp13_14_15 = temp13_14;
    temp13_14_15 += temp[15];
    Ctxt temp12_13_14_15 = temp12_13_14;
    temp12_13_14_15 += temp[15];
    Ctxt temp16_17 = temp[16];
    temp16_17 += temp[17];
    Ctxt temp16_18 = temp[16];
    temp16_18 += temp[18];
    Ctxt temp16_19 = temp[16];
    temp16_19 += temp[19];
    Ctxt temp17_18 = temp[17];
    temp17_18 += temp[18];
    Ctxt temp17_19 = temp[17];
    temp17_19 += temp[19];
    Ctxt temp18_19 = temp[18];
    temp18_19 += temp[19];
    Ctxt temp16_17_18 = temp16_17;
    temp16_17_18 += temp[18];
    Ctxt temp16_17_19 = temp16_17;
    temp16_17_19 += temp[19];
    Ctxt temp16_18_19 = temp16_18;
    temp16_18_19 += temp[19];
    Ctxt temp17_18_19 = temp17_18;
    temp17_18_19 += temp[19];
    Ctxt temp16_17_18_19 = temp16_17_18;
    temp16_17_18_19 += temp[19];
    Ctxt temp20_21 = temp[20];
    temp20_21 += temp[21];
    Ctxt temp20_22 = temp[20];
    temp20_22 += temp[22];
    Ctxt temp20_23 = temp[20];
    temp20_23 += temp[23];
    Ctxt temp21_22 = temp[21];
    temp21_22 += temp[22];
    Ctxt temp21_23 = temp[21];
    temp21_23 += temp[23];
    Ctxt temp22_23 = temp[22];
    temp22_23 += temp[23];
    Ctxt temp20_21_22 = temp20_21;
    temp20_21_22 += temp[22];
    Ctxt temp20_21_23 = temp20_21;
    temp20_21_23 += temp[23];
    Ctxt temp20_22_23 = temp20_22;
    temp20_22_23 += temp[23];
    Ctxt temp21_22_23 = temp21_22;
    temp21_22_23 += temp[23];
    Ctxt temp20_21_22_23 = temp20_21_22;
    temp20_21_22_23 += temp[23];
    Ctxt temp24_25 = temp[24];
    temp24_25 += temp[25];
    Ctxt temp24_26 = temp[24];
    temp24_26 += temp[26];
    Ctxt temp24_27 = temp[24];
    temp24_27 += temp[27];
    Ctxt temp25_26 = temp[25];
    temp25_26 += temp[26];
    Ctxt temp25_27 = temp[25];
    temp25_27 += temp[27];
    Ctxt temp26_27 = temp[26];
    temp26_27 += temp[27];
    Ctxt temp24_25_26 = temp24_25;
    temp24_25_26 += temp[26];
    Ctxt temp24_25_27 = temp24_25;
    temp24_25_27 += temp[27];
    Ctxt temp24_26_27 = temp24_26;
    temp24_26_27 += temp[27];
    Ctxt temp25_26_27 = temp25_26;
    temp25_26_27 += temp[27];
    Ctxt temp24_25_26_27 = temp24_25_26;
    temp24_25_26_27 += temp[27];
    Ctxt temp28_29 = temp[28];
    temp28_29 += temp[29];
    Ctxt temp28_30 = temp[28];
    temp28_30 += temp[30];
    Ctxt temp28_31 = temp[28];
    temp28_31 += temp[31];
    Ctxt temp29_30 = temp[29];
    temp29_30 += temp[30];
    Ctxt temp29_31 = temp[29];
    temp29_31 += temp[31];
    Ctxt temp30_31 = temp[30];
    temp30_31 += temp[31];
    Ctxt temp28_29_30 = temp28_29;
    temp28_29_30 += temp[30];
    Ctxt temp28_29_31 = temp28_29;
    temp28_29_31 += temp[31];
    Ctxt temp28_30_31 = temp28_30;
    temp28_30_31 += temp[31];
    Ctxt temp29_30_31 = temp29_30;
    temp29_30_31 += temp[31];
    Ctxt temp28_29_30_31 = temp28_29_30;
    temp28_29_30_31 += temp[31];
    Ctxt temp32_33 = temp[32];
    temp32_33 += temp[33];
    Ctxt temp32_34 = temp[32];
    temp32_34 += temp[34];
    Ctxt temp32_35 = temp[32];
    temp32_35 += temp[35];
    Ctxt temp33_34 = temp[33];
    temp33_34 += temp[34];
    Ctxt temp33_35 = temp[33];
    temp33_35 += temp[35];
    Ctxt temp34_35 = temp[34];
    temp34_35 += temp[35];
    Ctxt temp32_33_34 = temp32_33;
    temp32_33_34 += temp[34];
    Ctxt temp32_33_35 = temp32_33;
    temp32_33_35 += temp[35];
    Ctxt temp32_34_35 = temp32_34;
    temp32_34_35 += temp[35];
    Ctxt temp33_34_35 = temp33_34;
    temp33_34_35 += temp[35];
    Ctxt temp32_33_34_35 = temp32_33_34;
    temp32_33_34_35 += temp[35];

    eData[0] += temp1_3;
    eData[0] += temp4_5_6_7;
    eData[0] += temp8_11;
    eData[0] += temp14_15;
    eData[0] += temp16_17_19;
    eData[0] += temp20_21_22;
    eData[0] += temp24_25;
    eData[0] += temp29_30_31;
    eData[0] += temp33_34_35;
    eData[1] += temp0_2_3;
    eData[1] += temp4_6;
    eData[1] += temp8_10;
    eData[1] += temp12_13_15;
    eData[1] += temp17_18;
    eData[1] += temp20_21_22_23;
    eData[1] += temp24_25_26;
    eData[1] += temp28_31;
    eData[1] += temp32_33_34;
    eData[2] = temp[1];
    eData[2] += temp4_5_7;
    eData[2] += temp8_9_10;
    eData[2] += temp12_14;
    eData[2] += temp16_17_18_19;
    eData[2] += temp20_21_23;
    eData[2] += temp25_26_27;
    eData[2] += temp28_29_30_31;
    eData[2] += temp32_33_35;
    eData[3] += temp0_1_2;
    eData[3] += temp4_6_7;
    eData[3] += temp8_9_10_11;
    eData[3] += temp[14];
    eData[3] += temp17_18_19;
    eData[3] += temp20_22_23;
    eData[3] += temp24_25_27;
    eData[3] += temp[28];
    eData[3] += temp32_33_34;
    eData[4] += temp0_1_3;
    eData[4] += temp5_6_7;
    eData[4] += temp9_11;
    eData[4] += temp13_15;
    eData[4] += temp16_18;
    eData[4] += temp20_21_23;
    eData[4] += temp24_25_26_27;
    eData[4] += temp28_29_31;
    eData[4] += temp34_35;
    eData[5] = temp0_2;
    eData[5] += temp4_7;
    eData[5] += temp8_10_11;
    eData[5] += temp12_13_15;
    eData[5] += temp17_19;
    eData[5] += temp20_21_22_23;
    eData[5] += temp24_26;
    eData[5] += temp28_29_30_31;
    eData[5] += temp32_33_34_35;
    eData[6] += temp0_1_3;
    eData[6] += temp4_5_7;
    eData[6] += temp9_10_11;
    eData[6] += temp12_13_14;
    eData[6] += temp[17];
    eData[6] += temp20_21_22_23;
    eData[6] += temp25_26_27;
    eData[6] += temp28_30_31;
    eData[6] += temp[35];
    eData[7] += temp1_2_3;
    eData[7] += temp4_6;
    eData[7] += temp8_9_10;
    eData[7] += temp12_14;
    eData[7] += temp16_18_19;
    eData[7] += temp21_23;
    eData[7] += temp24_26_27;
    eData[7] += temp28_29_30_31;
    eData[7] += temp32_34;
    eData[8] = temp0_1_2_3;
    eData[8] += temp5_7;
    eData[8] += temp10_11;
    eData[8] += temp13_14_15;
    eData[8] += temp16_18;
    eData[8] += temp20_22_23;
    eData[8] += temp24_25_26_27;
    eData[8] += temp29_31;
    eData[8] += temp32_33_34_35;
    eData[9] += temp2_3;
    eData[9] += temp4_6_7;
    eData[9] += temp8_10;
    eData[9] += temp12_13_14_15;
    eData[9] += temp16_17;
    eData[9] += temp20_23;
    eData[9] += temp24_25_26;
    eData[9] += temp28_29_30_31;
    eData[9] += temp33_34;
    eData[10] += temp[1];
    eData[10] += temp4_5_6_7;
    eData[10] += temp9_11;
    eData[10] += temp12_13_15;
    eData[10] += temp17_19;
    eData[10] += temp21_22;
    eData[10] += temp24_26_27;
    eData[10] += temp29_30_31;
    eData[10] += temp32_33_34_35;
    eData[11] = temp0_1_2_3;
    eData[11] += temp4_5_6;
    eData[11] += temp8_10;
    eData[11] += temp13_14;
    eData[11] += temp16_17_18_19;
    eData[11] += temp21_23;
    eData[11] += temp25_26_27;
    eData[11] += temp28_29_30;
    eData[11] += temp32_34_35;
    eData[12] += temp0_1;
    eData[12] += temp5_6_7;
    eData[12] += temp9_10_11;
    eData[12] += temp13_15;
    eData[12] += temp16_17_18_19;
    eData[12] += temp20_23;
    eData[12] += temp26_27;
    eData[12] += temp28_29_31;
    eData[12] += temp32_33_34;
    eData[13] += temp0_1_2;
    eData[13] += temp4_7;
    eData[13] += temp8_9_10;
    eData[13] += temp12_14_15;
    eData[13] += temp16_18;
    eData[13] += temp20_22;
    eData[13] += temp24_25_27;
    eData[13] += temp29_30;
    eData[13] += temp32_33_34_35;
    eData[14] = temp1_2_3;
    eData[14] += temp4_5_6_7;
    eData[14] += temp8_9_11;
    eData[14] += temp[13];
    eData[14] += temp16_17_19;
    eData[14] += temp20_21_22;
    eData[14] += temp24_26;
    eData[14] += temp28_29_30_31;
    eData[14] += temp32_33_35;
    eData[15] += temp0_1_3;
    eData[15] += temp[4];
    eData[15] += temp8_9_10;
    eData[15] += temp12_13_14;
    eData[15] += temp16_18_19;
    eData[15] += temp20_21_22_23;
    eData[15] += temp[26];
    eData[15] += temp29_30_31;
    eData[15] += temp32_34_35;
    eData[16] += temp0_1_2_3;
    eData[16] += temp4_5_7;
    eData[16] += temp10_11;
    eData[16] += temp12_13_15;
    eData[16] += temp17_18_19;
    eData[16] += temp21_23;
    eData[16] += temp25_27;
    eData[16] += temp28_30;
    eData[16] += temp32_33_35;
    eData[17] = temp0_2;
    eData[17] += temp4_5_6_7;
    eData[17] += temp8_9_10_11;
    eData[17] += temp12_14;
    eData[17] += temp16_19;
    eData[17] += temp20_22_23;
    eData[17] += temp24_25_27;
    eData[17] += temp29_31;
    eData[17] += temp32_33_34_35;
    eData[18] += temp1_2_3;
    eData[18] += temp4_6_7;
    eData[18] += temp[11];
    eData[18] += temp12_13_15;
    eData[18] += temp16_17_19;
    eData[18] += temp21_22_23;
    eData[18] += temp24_25_26;
    eData[18] += temp[29];
    eData[18] += temp32_33_34_35;
    eData[19] += temp0_2_3;
    eData[19] += temp4_5_6_7;
    eData[19] += temp8_10;
    eData[19] += temp13_14_15;
    eData[19] += temp16_18;
    eData[19] += temp20_21_22;
    eData[19] += temp24_26;
    eData[19] += temp28_30_31;
    eData[19] += temp33_35;
    eData[20] = temp0_1_2_3;
    eData[20] += temp5_7;
    eData[20] += temp8_9_10_11;
    eData[20] += temp12_13_14_15;
    eData[20] += temp17_19;
    eData[20] += temp22_23;
    eData[20] += temp25_26_27;
    eData[20] += temp28_30;
    eData[20] += temp32_34_35;
    eData[21] += temp0_1_2;
    eData[21] += temp4_5_6_7;
    eData[21] += temp9_10;
    eData[21] += temp14_15;
    eData[21] += temp16_18_19;
    eData[21] += temp20_22;
    eData[21] += temp24_25_26_27;
    eData[21] += temp28_29;
    eData[21] += temp32_35;
    eData[22] += temp0_2_3;
    eData[22] += temp5_6_7;
    eData[22] += temp8_9_10_11;
    eData[22] += temp[13];
    eData[22] += temp16_17_18_19;
    eData[22] += temp21_23;
    eData[22] += temp24_25_27;
    eData[22] += temp29_31;
    eData[22] += temp33_34;
    eData[23] = temp1_2_3;
    eData[23] += temp4_5_6;
    eData[23] += temp8_10_11;
    eData[23] += temp12_13_14_15;
    eData[23] += temp16_17_18;
    eData[23] += temp20_22;
    eData[23] += temp25_26;
    eData[23] += temp28_29_30_31;
    eData[23] += temp33_35;
    eData[24] += temp2_3;
    eData[24] += temp4_5_7;
    eData[24] += temp8_9_10;
    eData[24] += temp12_13;
    eData[24] += temp17_18_19;
    eData[24] += temp21_22_23;
    eData[24] += temp25_27;
    eData[24] += temp28_29_30_31;
    eData[24] += temp32_35;
    eData[25] += temp0_1_3;
    eData[25] += temp5_6;
    eData[25] += temp8_9_10_11;
    eData[25] += temp12_13_14;
    eData[25] += temp16_19;
    eData[25] += temp20_21_22;
    eData[25] += temp24_26_27;
    eData[25] += temp28_30;
    eData[25] += temp32_34;
    eData[26] = temp0_2;
    eData[26] += temp4_5_6_7;
    eData[26] += temp8_9_11;
    eData[26] += temp13_14_15;
    eData[26] += temp16_17_18_19;
    eData[26] += temp20_21_23;
    eData[26] += temp[25];
    eData[26] += temp28_29_31;
    eData[26] += temp32_33_34;
    eData[27] += temp[2];
    eData[27] += temp5_6_7;
    eData[27] += temp8_10_11;
    eData[27] += temp12_13_15;
    eData[27] += temp[16];
    eData[27] += temp20_21_22;
    eData[27] += temp24_25_26;
    eData[27] += temp28_30_31;
    eData[27] += temp32_33_34_35;
    eData[28] += temp1_3;
    eData[28] += temp4_6;
    eData[28] += temp8_9_11;
    eData[28] += temp12_13_14_15;
    eData[28] += temp16_17_19;
    eData[28] += temp22_23;
    eData[28] += temp24_25_27;
    eData[28] += temp29_30_31;
    eData[28] += temp33_35;
    eData[29] = temp0_1_3;
    eData[29] += temp5_7;
    eData[29] += temp8_9_10_11;
    eData[29] += temp12_14;
    eData[29] += temp16_17_18_19;
    eData[29] += temp20_21_22_23;
    eData[29] += temp24_26;
    eData[29] += temp28_31;
    eData[29] += temp32_34_35;
    eData[30] += temp0_1_2;
    eData[30] += temp[5];
    eData[30] += temp8_9_10_11;
    eData[30] += temp13_14_15;
    eData[30] += temp16_18_19;
    eData[30] += temp[23];
    eData[30] += temp24_25_27;
    eData[30] += temp28_29_31;
    eData[30] += temp33_34_35;
    eData[31] += temp0_2;
    eData[31] += temp4_6_7;
    eData[31] += temp9_11;
    eData[31] += temp12_14_15;
    eData[31] += temp16_17_18_19;
    eData[31] += temp20_22;
    eData[31] += temp25_26_27;
    eData[31] += temp28_30;
    eData[31] += temp32_33_34;
    eData[32] = temp1_2_3;
    eData[32] += temp4_6;
    eData[32] += temp8_10_11;
    eData[32] += temp12_13_14_15;
    eData[32] += temp17_19;
    eData[32] += temp20_21_22_23;
    eData[32] += temp24_25_26_27;
    eData[32] += temp29_31;
    eData[32] += temp34_35;
    eData[33] += temp0_1_2_3;
    eData[33] += temp4_5;
    eData[33] += temp8_11;
    eData[33] += temp12_13_14;
    eData[33] += temp16_17_18_19;
    eData[33] += temp21_22;
    eData[33] += temp26_27;
    eData[33] += temp28_30_31;
    eData[33] += temp32_34;
    eData[34] += temp0_1_3;
    eData[34] += temp5_7;
    eData[34] += temp9_10;
    eData[34] += temp12_14_15;
    eData[34] += temp17_18_19;
    eData[34] += temp20_21_22_23;
    eData[34] += temp[25];
    eData[34] += temp28_29_30_31;
    eData[34] += temp33_35;
    eData[35] = temp1_2;
    eData[35] += temp4_5_6_7;
    eData[35] += temp9_11;
    eData[35] += temp13_14_15;
    eData[35] += temp16_17_18;
    eData[35] += temp20_22_23;
    eData[35] += temp24_25_26_27;
    eData[35] += temp28_29_30;
    eData[35] += temp32_34;
}
// Compute the Sbox,(x0,x1,x2)——>(x0,x0*x2+x1,-x0*x1+x0*x2+x2)
void HE_Sbox(vector<Ctxt> &eData)
{

    Ctxt c01 = eData[1];
    Ctxt c02 = eData[2];
    c01.multiplyBy(eData[0]);
    c02.multiplyBy(eData[0]);

    eData[1] += c02;
    eData[2] -= c01;
    eData[2] += c02;

    for (long j = 3; j < BlockWords; j += 3)
    {
        c01 = eData[j + 1];
        c01.multiplyBy(eData[j]);

        c02 = eData[j + 2];
        c02.multiplyBy(eData[j]);

        eData[j + 1] += c02;
        eData[j + 2] -= c01;
        eData[j + 2] += c02;
    }
}

void HE_Add(vector<Ctxt> &encryptedKeyStream, vector<vec_long> &Xset, vector<Ctxt> &encryptedSymKey, Cmodulus &cmodulus)
{
    Ctxt tmpCtxt(encryptedKeyStream[0]);
    zzX encodedXseti;
    zz_pX encodedtemp;
    for (long j = 0; j < BlockWords; j++)
    {
        cmodulus.iFFT(encodedtemp, Xset[j]);
        convert(encodedXseti, encodedtemp);
        tmpCtxt = encryptedSymKey[j];
        tmpCtxt.multByConstant(encodedXseti);
        encryptedKeyStream[j] += tmpCtxt;
    }
}
int main()
{
    std::cout << "Nr: " << Nr << std::endl;
    std::cout << "BlockWord: " << BlockWords << std::endl;
    std::cout << "BlockPlainWord: " << BlockPlainWords << std::endl;
    std::cout << "PlainMod: " << PlainMod << std::endl;
    std::cout << "PlainBlock: " << PlainBlock << std::endl;
    std::cout << "nslots: " << nslots << std::endl;
    std::cout << "Para_bits: " << Para_bits << std::endl;
    std::cout << "Para_c: " << Para_c << std::endl;
    //========================= client offline =========================
    // initial vector
    vector<long> IV(BlockWords);
    for (unsigned i = 0; i < BlockWords; i++)
    {
        IV[i] = i + 1;
    }
    // generate symkey
    random_device rd;
    vector<long> SymKey(BlockWords);
    for (unsigned i = 0; i < BlockWords; i++)
    {
        SymKey[i] = rd() % PlainMod;
    }
    std::cout << "SymKey generated." << std::endl;

    // Generating Public Key and encrypting the symmetric key
    auto start = std::chrono::high_resolution_clock::now();
    shared_ptr<Context> context(ContextBuilder<BGV>()
                                    .m(Para_m)
                                    .p(Para_p)
                                    .r(Para_r)
                                    .bits(Para_bits)
                                    .c(Para_c)
                                    .buildPtr());
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_seconds_context = end - start;
    std::cout << "Context generation time: " << elapsed_seconds_context.count() << "s\n";

    auto start_PubKey = std::chrono::high_resolution_clock::now();
    SecKey secretKey(*context);
    secretKey.GenSecKey();
    unique_ptr<PubKey> publicKey = std::make_unique<helib::PubKey>(secretKey);
    auto end_PubKey = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_seconds_PubKey = end_PubKey - start_PubKey;
    std::cout << "PublicKey generation time: " << elapsed_seconds_PubKey.count() << "s\n";

    const helib::PAlgebra &zMStar = context->getZMStar();

    long root = 3; // m-th root of unity modulo p
    if (Para_m == 65536)
    {
        root = 3;
    }
    if (Para_m == 32768)
    {
        root = 9;
    }
    if (Para_m == 16384)
    {
        root = 81;
    }
    helib::Cmodulus cmodulus(zMStar, Para_p, root);

    context->printout();
    std::cout << std::endl;

    long Qbits = context->bitSizeOfQ();
    double SecLevel = context->securityLevel();

    auto start_keyEncryption = std::chrono::high_resolution_clock::now();
    vector<Ctxt> encryptedSymKey;
    encryptSymKey(encryptedSymKey, SymKey, publicKey, cmodulus, nslots);
    auto end_keyEncryption = std::chrono::high_resolution_clock::now();
    double keyEncryption = std::chrono::duration<double>(end_keyEncryption - start_keyEncryption).count();
    std::cout << "SymKey FHE time: " << keyEncryption << "s\n";

    for (int test = 0; test < 10; test++)
    {
        std::cout << "--------------- Test = " << test << "---------------" << std::endl;
        // Generating key stream
        std::vector<long> NonceSet(PlainBlock);
        std::vector<long> KeyStream(PlainWords);
        std::vector<long> RoundKey(BlockWords);
        long nonce;
        long block_num;
        std::vector<long> state(BlockWords);
        Keccak_HashInstance shake128_2;
        std::cout << "Generating KeyStream..." << std::endl;
        auto start_keyStream = std::chrono::high_resolution_clock::now();
        uint64_t start_cycle1 = rdtsc();
        for (long counter = counter_begin; counter <= counter_end; counter++)
        {
            nonce = generate_secure_random_int(NonceSize);
            random_init_shake(nonce, counter, shake128_2);
            block_num = counter - counter_begin;
            NonceSet[block_num] = nonce;
            for (unsigned r = 0; r <= Nr; r++)
            {
                for (unsigned i = 0; i < BlockWords; ++i)
                {
                    RoundKey[i] = (SymKey[i] * generate_random_field_element(shake128_2, false, max_prime_size, PlainMod)) % PlainMod;
                }
                if (r == 0)
                {
                    for (unsigned i = 0; i < BlockWords; i++)
                    {
                        state[i] = (RoundKey[i] + IV[i]) % PlainMod;
                    }
                }
                else if (r < Nr)
                {
                    yusP.M36(state);  // linear
                    yusP.Sbox(state); // sbox
                    for (unsigned i = 0; i < BlockWords; i++)
                    {
                        state[i] = (state[i] + RoundKey[i]) % PlainMod;
                    }
                }
                else
                {                     // last round
                    yusP.M36(state);  // Liner
                    yusP.Sbox(state); // sbox
                    for (unsigned i = 0; i < BlockWords; i++)
                    {
                        state[i] = (state[i] + RoundKey[i]) % PlainMod;
                    }
                    yusP.M36(state); // Liner
                    memcpy(&KeyStream[(block_num)*BlockPlainWords], state.data(), BlockPlainWords * sizeof(long));
                }
            }
        }
        uint64_t end_cycle1 = rdtsc();
        auto end_keyStream = std::chrono::high_resolution_clock::now();
        double Client_offtime = std::chrono::duration_cast<std::chrono::duration<double>>(end_keyStream - start_keyStream).count();
        std::cout << "Encryption offline total time: " << Client_offtime << "s\n";
        uint64_t cycle_count1 = end_cycle1 - start_cycle1;
        std::cout << "Encryption offline total cycles: " << cycle_count1 << std::endl;
        RoundKey.clear();
        state.clear();
        Keccak_HashFinal(&shake128_2, nullptr);

        // if (!writeEncryptedSymKey(encryptedSymKey, "Client_encryptedSymKey.bin"))
        // {
        //     return false;
        // }
        // std::cout << "Client_encryptedSymKey.bin has been written to file." << std::endl;

        // ================================= server offline ====================================
        std::cout << "Generating XOF stream..." << std::endl;
        std::vector<vec_long> Xset(NrBlockWords);
        for (int i = 0; i < NrBlockWords; i++)
        {
            Xset[i].SetLength(nslots);
            for (int j = 0; j < nslots; j++)
            {
                Xset[i][j] = 0;
            }
        }
        long rB;
        Keccak_HashInstance shake128_3;
        auto start_XOF = std::chrono::high_resolution_clock::now();
        for (long counter = counter_begin; counter <= counter_end; counter++)
        {
            block_num = counter - counter_begin;
            nonce = NonceSet[block_num];
            random_init_shake(nonce, counter, shake128_3);
            for (unsigned r = 0; r <= Nr; r++)
            {
                rB = r * BlockWords;
                for (unsigned i = 0; i < BlockWords; ++i)
                {
                    Xset[rB + i][block_num] = generate_random_field_element(shake128_3, false, max_prime_size, PlainMod);
                }
            }
        }
        auto end_XOF = std::chrono::high_resolution_clock::now();
        double XOF_time = std::chrono::duration<double>(end_XOF - start_XOF).count();
        std::cout << "XOF stream Generation time: " << XOF_time << "s\n";
        Keccak_HashFinal(&shake128_3, nullptr);

        int noise_budget = min_noise_budget(encryptedSymKey);
        std::cout << "noise budget initially: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        double Sbox_time = 0, Linear_time = 0, Add_time = 0;
        auto start_sbox = std::chrono::high_resolution_clock::now();
        auto end_sbox = std::chrono::high_resolution_clock::now();
        auto start_linear = std::chrono::high_resolution_clock::now();
        auto end_linear = std::chrono::high_resolution_clock::now();
        auto start_add = std::chrono::high_resolution_clock::now();
        auto end_add = std::chrono::high_resolution_clock::now();
        vector<double> sbox_set(Nr);
        vector<double> linear_set(Nr + 1);
        vector<Ctxt> encryptedKeyStream = encryptedSymKey;
        std::cout << "whiteround start" << std::endl;
        zzX encodedXseti;
        zz_pX encodedtemp;
        start_add = std::chrono::high_resolution_clock::now();
        for (long i = 0; i < BlockWords; i++)
        { // encrypt the encoded key
            cmodulus.iFFT(encodedtemp, Xset[i]);
            convert(encodedXseti, encodedtemp);
            encryptedKeyStream[i].multByConstant(encodedXseti);
            encryptedKeyStream[i].addConstant(IV[i]);
        }
        end_add = std::chrono::high_resolution_clock::now();
        Add_time += std::chrono::duration<double>(end_add - start_add).count();
        std::cout << "whiteround time: " << Add_time << "s\n";
        Xset.erase(Xset.begin(), Xset.begin() + BlockWords);
        encodedXseti.kill();

        noise_budget = min_noise_budget(encryptedKeyStream);
        std::cout << "noise budget after Whiteround: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        for (long r = 1; r < Nr; r++)
        {
            std::cout << "Round " << r << " start" << std::endl;
            start_linear = std::chrono::high_resolution_clock::now();
            // Linear Layer
            HE_M(encryptedKeyStream);
            end_linear = std::chrono::high_resolution_clock::now();
            Linear_time += std::chrono::duration<double>(end_linear - start_linear).count();
            linear_set[r - 1] = std::chrono::duration<double>(end_linear - start_linear).count();
            noise_budget = min_noise_budget(encryptedKeyStream);
            std::cout << "noise budget after linear: " << noise_budget << std::endl;
            if (noise_budget <= 0)
            {
                std::cerr << "noise budget is not enough!!!" << std::endl;
                continue;
            }
            start_sbox = std::chrono::high_resolution_clock::now();
            // S Layer
            HE_Sbox(encryptedKeyStream);
            end_sbox = std::chrono::high_resolution_clock::now();
            Sbox_time += std::chrono::duration<double>(end_sbox - start_sbox).count();
            sbox_set[r - 1] = std::chrono::duration<double>(end_sbox - start_sbox).count();
            noise_budget = min_noise_budget(encryptedKeyStream);
            std::cout << "noise budget after sbox: " << noise_budget << std::endl;
            if (noise_budget <= 0)
            {
                std::cerr << "noise budget is not enough!!!" << std::endl;
                continue;
            }
            // Round Key Addition
            start_add = std::chrono::high_resolution_clock::now();
            HE_Add(encryptedKeyStream, Xset, encryptedSymKey, cmodulus);
            end_add = std::chrono::high_resolution_clock::now();
            Add_time += std::chrono::duration<double>(end_add - start_add).count();
            Xset.erase(Xset.begin(), Xset.begin() + BlockWords);
            noise_budget = min_noise_budget(encryptedKeyStream);
            std::cout << "noise budget after Add: " << noise_budget << std::endl;
            if (noise_budget <= 0)
            {
                std::cerr << "noise budget is not enough!!!" << std::endl;
                continue;
            }
        }
        std::cout << "the last Round " << Nr << " start" << std::endl;
        start_linear = std::chrono::high_resolution_clock::now();
        // Linear Layer
        HE_M(encryptedKeyStream);
        end_linear = std::chrono::high_resolution_clock::now();
        Linear_time += std::chrono::duration<double>(end_linear - start_linear).count();
        linear_set[Nr - 1] = std::chrono::duration<double>(end_linear - start_linear).count();
        noise_budget = min_noise_budget(encryptedKeyStream);
        std::cout << "noise budget after linear: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        start_sbox = std::chrono::high_resolution_clock::now();
        // S Layer
        HE_Sbox(encryptedKeyStream);
        end_sbox = std::chrono::high_resolution_clock::now();
        Sbox_time += std::chrono::duration<double>(end_sbox - start_sbox).count();
        sbox_set[Nr - 1] = std::chrono::duration<double>(end_sbox - start_sbox).count();
        noise_budget = min_noise_budget(encryptedKeyStream);
        std::cout << "noise budget after sbox: " << noise_budget << std::endl;
        // add
        start_add = std::chrono::high_resolution_clock::now();
        HE_Add(encryptedKeyStream, Xset, encryptedSymKey, cmodulus);
        end_add = std::chrono::high_resolution_clock::now();
        Add_time += std::chrono::duration<double>(end_add - start_add).count();
        Xset.erase(Xset.begin(), Xset.begin() + BlockWords);
        noise_budget = min_noise_budget(encryptedKeyStream);
        std::cout << "noise budget after Add: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        start_linear = std::chrono::high_resolution_clock::now();
        // Linear Layer
        HE_M(encryptedKeyStream);
        end_linear = std::chrono::high_resolution_clock::now();
        Linear_time += std::chrono::duration<double>(end_linear - start_linear).count();
        linear_set[Nr] = std::chrono::duration<double>(end_linear - start_linear).count();
        noise_budget = min_noise_budget(encryptedKeyStream);
        std::cout << "noise budget after linear: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        // truncation
        encryptedKeyStream.erase(encryptedKeyStream.begin() + BlockPlainWords, encryptedKeyStream.end());
        // XOF_time,Add_time、Sbox_time、Linear_time
        std::cout << "XOF time: " << XOF_time << "s\n";
        std::cout << "Add time: " << Add_time << "s\n";
        std::cout << "Sbox time: " << Sbox_time << "s\n";
        std::cout << "Linear time: " << Linear_time << "s\n";
        // Server_offtime
        double Server_offtime = XOF_time + Add_time + Sbox_time + Linear_time;
        std::cout << "Server offline total time: " << Server_offtime << "s\n";
        std::cout << "sbox_timeset: " << sbox_set << endl;
        std::cout << "linear_timeset: " << linear_set << endl;

        // ================================= Client online =================================
        vector<long> PlainStream(PlainWords);
        for (int i = 0; i < PlainWords; i++)
        {
            PlainStream[i] = rd() % PlainMod;
        }
        // 加密
        vector<vec_long> CipherStream(BlockPlainWords);
        for (int i = 0; i < BlockPlainWords; i++)
        {
            CipherStream[i].SetLength(nslots);
            for (int j = 0; j < nslots; j++)
            {
                CipherStream[i][j] = 0;
            }
        }
        long jBP;
        auto start_ClientOnline = std::chrono::high_resolution_clock::now();
        uint64_t start_cycle2 = rdtsc();
        for (int j = 0; j < PlainBlock; j++)
        {
            jBP = j * BlockPlainWords;
            for (int i = 0; i < BlockPlainWords; i++)
            {
                CipherStream[i][j] = (PlainStream[jBP + i] - KeyStream[jBP + i]) % PlainMod;
            }
        }
        uint64_t end_cycle2 = rdtsc();
        auto end_ClientOnline = std::chrono::high_resolution_clock::now();
        uint64_t cycle_count2 = end_cycle2 - start_cycle2;
        uint64_t cycle_count = cycle_count1 + cycle_count2;
        double Client_ontime = std::chrono::duration<double>(end_ClientOnline - start_ClientOnline).count();
        std::cout << "Client onine total time:" << std::chrono::duration<double>(end_ClientOnline - start_ClientOnline).count() << "s\n";
        double Client_totaltime = Client_offtime + Client_ontime;
        std::cout << "Client total time: " << Client_totaltime << "s\n";

        double Cli_throughput = (8 * cycle_count) / Plainbits; // Cycle/Byte
        std::cout << "Client Throughput: " << Cli_throughput << "Cycle/Byte\n";
        // ======================= server online ===================================
        vector<Ctxt> encryptedPlainStream = encryptedKeyStream;
        encryptedKeyStream.clear();
        ZZX encodedCipherStreami;
        auto start_ServerOnline = std::chrono::high_resolution_clock::now();
        for (int i = 0; i < BlockPlainWords; i++)
        {
            cmodulus.iFFT(encodedtemp, CipherStream[i]);
            convert(encodedCipherStreami, encodedtemp);
            encryptedPlainStream[i].addConstant(encodedCipherStreami);
        }
        auto end_ServerOnline = std::chrono::high_resolution_clock::now();
        double server_ontime = std::chrono::duration<double>(end_ServerOnline - start_ServerOnline).count();
        std::cout << "Server onine total time:" << server_ontime << "s\n";
        CipherStream.clear();
        encodedCipherStreami.kill();
        encodedtemp.kill();

        noise_budget = min_noise_budget(encryptedPlainStream);
        std::cout << "noise budget after online: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        double Server_totaltime = Server_offtime + server_ontime;
        double Ser_throughput = Plainbits / (pow(2, 13) * Server_totaltime);
        std::cout << "Server total time: " << Server_totaltime << "s\n";
        std::cout << "Server Throughput: " << Ser_throughput << "KiB/s\n";

        std::cout << "Test " << test << " finished." << std::endl;
    }
    return 0;
}
