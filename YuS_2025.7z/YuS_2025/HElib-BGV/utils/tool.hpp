#ifndef TOOL_HPP
#define TOOL_HPP

#include <iostream>
#include <vector>
#include <random>
#include <climits>
#include <helib/helib.h>

extern "C"
{
#include "../keccak/KeccakHash.h"
}

long generate_secure_random_int(unsigned m);

void random_init_shake(long nonce, long block_counter, Keccak_HashInstance &shake128_);

long generate_random_field_element(Keccak_HashInstance &shake128, bool allow_zero, long max_prime_size, long PlainMod);

int min_noise_budget(std::vector<helib::Ctxt> &eData);

bool writeEncryptedSymKey(const std::vector<helib::Ctxt> &encryptedSymKey, const std::string &filename);

void encryptSymKey(std::vector<helib::Ctxt> &encryptedSymKey, const std::vector<long> &SymKey, std::unique_ptr<helib::PubKey> &pk, 
                   const helib::Cmodulus &cmodulus,const long nslots);

inline uint64_t rdtsc() {
    uint32_t lo, hi;
    __asm__ __volatile__ (
        "rdtsc"
        : "=a" (lo), "=d" (hi)
    );
    return (static_cast<uint64_t>(hi) << 32) | lo;
}

#endif // TOOL_HPP