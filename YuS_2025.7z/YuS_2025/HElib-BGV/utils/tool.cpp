#include "tool.hpp"

long generate_secure_random_int(unsigned m) {
    if (m > 64) {
        throw std::invalid_argument("m exceeds the maximum bit size of long");
    }

    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<long> dis(0, (1ULL << m) - 1);

    return dis(gen);
}
void random_init_shake(long nonce, long block_counter, Keccak_HashInstance &shake128_)
{
    uint8_t seed[16];

    *((long *)seed) = htobe64(nonce);
    *((long *)(seed + 8)) = htobe64(block_counter);

    if (SUCCESS != Keccak_HashInitialize_SHAKE128(&shake128_))
        throw std::runtime_error("failed to init shake");
    if (SUCCESS != Keccak_HashUpdate(&shake128_, seed, sizeof(seed) * 8))
        throw std::runtime_error("SHAKE128 update failed");
    if (SUCCESS != Keccak_HashFinal(&shake128_, NULL))
        throw std::runtime_error("SHAKE128 final failed");
}
long generate_random_field_element(Keccak_HashInstance &shake128, bool allow_zero, long max_prime_size, long PlainMod)
{
    uint8_t random_bytes[sizeof(long)];
    while (1)
    {
        if (SUCCESS !=
            Keccak_HashSqueeze(&shake128, random_bytes, sizeof(random_bytes) * 8))
            throw std::runtime_error("SHAKE128 squeeze failed");
        long ele = be64toh(*((long *)random_bytes)) & max_prime_size;
        if (!allow_zero && ele == 0)
            continue;
        if (ele < PlainMod)
            return ele;
    }
}

int min_noise_budget(std::vector<helib::Ctxt> &eData)
{
    int min_noise = 10000;
    int noise;
    for (int i = 0; i < eData.size(); i++)
    {
        noise = eData[i].bitCapacity();
        if (noise < min_noise)
        {
            min_noise = noise;
        }
    }
    return min_noise;
}

bool writeEncryptedSymKey(const std::vector<helib::Ctxt> &encryptedSymKey, const std::string &filename)
{
    std::ofstream out(filename, std::ios::binary);
    if (!out.is_open())
    {
        std::cerr << "Failed to open " << filename << " for writing" << std::endl;
        return false;
    }

    for (const auto &ctxt : encryptedSymKey)
    {
        ctxt.writeTo(out);
    }

    out.close();

    return true;
}

void encryptSymKey(std::vector<helib::Ctxt> &encryptedSymKey, const std::vector<long> &SymKey, std::unique_ptr<helib::PubKey> &pk, const helib::Cmodulus &cmodulus,const long nslots)
{
    NTL::vec_long slotsData;
    slotsData.SetLength(nslots);
    long BlockWords = SymKey.size();
    encryptedSymKey.resize(BlockWords, helib::Ctxt(*pk));
    NTL::zz_pX temp;
    NTL::ZZX encodedData;
    for (long i = 0; i < BlockWords; i++)
    { // encrypt the encoded key
        for (long j = 0; j < nslots; j++)
        {
            slotsData[j] = SymKey[i];
        }
        cmodulus.iFFT(temp, slotsData);
        conv(encodedData, temp);
        pk->Encrypt(encryptedSymKey[i], encodedData);
    }
}