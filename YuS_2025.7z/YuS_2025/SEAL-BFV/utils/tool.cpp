#include "tool.hpp"

long generate_secure_random_int(unsigned m)
{
    if (m > 64)
    {
        throw std::invalid_argument("m exceeds the maximum bit size of long");
    }

    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<long> dis(0, (1ULL << m) - 1);

    return dis(gen);
}
void random_init_shake(long nonce, long block_counter, Keccak_HashInstance &shake128_)
{
    uint8_t seed[16];

    *((long *)seed) = htobe64(nonce);
    *((long *)(seed + 8)) = htobe64(block_counter);

    if (SUCCESS != Keccak_HashInitialize_SHAKE128(&shake128_))
        throw std::runtime_error("failed to init shake");
    if (SUCCESS != Keccak_HashUpdate(&shake128_, seed, sizeof(seed) * 8))
        throw std::runtime_error("SHAKE128 update failed");
    if (SUCCESS != Keccak_HashFinal(&shake128_, NULL))
        throw std::runtime_error("SHAKE128 final failed");
}
long generate_random_field_element(Keccak_HashInstance &shake128, bool allow_zero, long max_prime_size, long PlainMod)
{
    uint8_t random_bytes[sizeof(long)];
    while (1)
    {
        if (SUCCESS !=
            Keccak_HashSqueeze(&shake128, random_bytes, sizeof(random_bytes) * 8))
            throw std::runtime_error("SHAKE128 squeeze failed");
        long ele = be64toh(*((long *)random_bytes)) & max_prime_size;
        if (!allow_zero && ele == 0)
            continue;
        if (ele < PlainMod)
            return ele;
    }
}

int min_noise_budget(vector<Ciphertext> &eData, Decryptor &decryptor)
{
    int min_noise = 1000;
    long size = eData.size();
    for (int i = 0; i < size; i++)
    {
        int noise = decryptor.invariant_noise_budget(eData[i]);
        if (noise < min_noise)
        {
            min_noise = noise;
        }
    }
    return min_noise;
}

bool writeEncryptedSymKey(const vector<Ciphertext> &encryptedSymKey, const std::string &filename)
{
    std::ofstream out(filename, std::ios::binary);
    if (!out.is_open())
    {
        std::cerr << "Failed to open " << filename << " for writing" << std::endl;
        return false;
    }

    for (const auto &ctxt : encryptedSymKey)
    {
        ctxt.save(out);
    }

    out.close();

    return true;
}

void encryptSymKey(vector<Ciphertext> &encryptedSymKey, const vector<long> &SymKey, BatchEncoder &batch_encoder, Encryptor &encryptor, const long nslots)
{
    long BlockWords = SymKey.size();
    encryptedSymKey.resize(BlockWords);
    // 加密
    for (long i = 0; i < BlockWords; i++)
    { // encrypt the encoded key
        vector<long> SymKey_temp(nslots, SymKey[i]);
        Plaintext SymKey_plain;
        batch_encoder.encode(SymKey_temp, SymKey_plain);
        encryptor.encrypt(SymKey_plain, encryptedSymKey[i]);
    }
}