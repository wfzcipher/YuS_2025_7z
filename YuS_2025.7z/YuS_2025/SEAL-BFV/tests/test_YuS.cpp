#include <iostream>
#include <filesystem>
#include <vector>
#include <array>
#include <atomic>
#include <cmath>
#include <chrono>
#include <fstream>
#include <memory>
#include <random>
#include <climits>
#include <cassert>

#include <SEAL-4.1/seal/seal.h>

#include "../Symmetric/Yus_p.hpp"
#include "../utils/tool.hpp"
#include "params.hpp"

using namespace std;
using namespace seal;

/************************************************************************
  long p;          // plaintext primeplain_mod;
  long m;          // m-th cyclotomic polynomial
  long r;          // Lifting [defualt = 1]
  long bits;       // bits in the ciphertext modulus chain
  long c;          // columns in the key-switching matrix [default=2]
  long d;          // Degree of the field extension [default=1]
  long k;          // Security parameter [default=80]
  long s;          // Minimum number of slots [default=0]
************************************************************************/
//!!!!!!!!!!!!!!!!
constexpr unsigned BlockWords = 36;
constexpr unsigned BlockPlainWords = 24;
constexpr double TruncRate = BlockPlainWords / (double)BlockWords;

constexpr unsigned Nr = 6; // round number
constexpr long idx = 0;

constexpr tuple<long, long> paramMap[1][1] = {
    {
        // Nr = 6
        // {p, log2(m)}
        {65537, 15}, // 0 *
    }};

constexpr long log2Para_m = get<1>(paramMap[0][idx]) - 0;
constexpr long Para_p = get<0>(paramMap[0][idx]); // plaintext prime
constexpr long Para_m = 1 << log2Para_m;          // cyclotomic polynomial
constexpr long phi_m = Para_m >> 1;               // phi(m)
constexpr long Para_r = 1;                        // Lifting [defualt = 1]
//!!!!!!!!!!!!!!!
constexpr long nslots = phi_m;
constexpr unsigned PlainBlock = nslots - 0;

constexpr unsigned int log2_constexpr(unsigned long long n, unsigned int p = 0)
{
    return (n <= 1) ? p : log2_constexpr(n / 2, p + 1);
}
constexpr long PlainMod = Para_p;
constexpr unsigned Wordbits = log2_constexpr(PlainMod - 1) + 1;
constexpr unsigned NrBlockWords = BlockWords * (Nr + 1);
constexpr long KeyStreamWords = BlockWords * PlainBlock;
constexpr long PlainWords = BlockPlainWords * PlainBlock;
constexpr long Plainbits = Wordbits * PlainWords;

constexpr long max_prime_size = (1ULL << (Wordbits - 1)) - 1;

constexpr unsigned NonceSize = 64;
constexpr long counter_begin = 0;
constexpr long counter_end = PlainBlock + counter_begin - 1;

YusP yusP(PlainMod);

// Linear transformation
void HE_M(vector<Ciphertext> &eData, Evaluator &evaluator)
{
    vector<Ciphertext> temp = eData;
    Ciphertext temp0_1 = temp[0];
    evaluator.add_inplace(temp0_1, temp[1]);
    Ciphertext temp0_2 = temp[0];
    evaluator.add_inplace(temp0_2, temp[2]);
    Ciphertext temp0_3 = temp[0];
    evaluator.add_inplace(temp0_3, temp[3]);
    Ciphertext temp1_2 = temp[1];
    evaluator.add_inplace(temp1_2, temp[2]);
    Ciphertext temp1_3 = temp[1];
    evaluator.add_inplace(temp1_3, temp[3]);
    Ciphertext temp2_3 = temp[2];
    evaluator.add_inplace(temp2_3, temp[3]);
    Ciphertext temp0_1_2 = temp0_1;
    evaluator.add_inplace(temp0_1_2, temp[2]);
    Ciphertext temp0_1_3 = temp0_1;
    evaluator.add_inplace(temp0_1_3, temp[3]);
    Ciphertext temp0_2_3 = temp0_2;
    evaluator.add_inplace(temp0_2_3, temp[3]);
    Ciphertext temp1_2_3 = temp1_2;
    evaluator.add_inplace(temp1_2_3, temp[3]);
    Ciphertext temp0_1_2_3 = temp0_1_2;
    evaluator.add_inplace(temp0_1_2_3, temp[3]);
    Ciphertext temp4_5 = temp[4];
    evaluator.add_inplace(temp4_5, temp[5]);
    Ciphertext temp4_6 = temp[4];
    evaluator.add_inplace(temp4_6, temp[6]);
    Ciphertext temp4_7 = temp[4];
    evaluator.add_inplace(temp4_7, temp[7]);
    Ciphertext temp5_6 = temp[5];
    evaluator.add_inplace(temp5_6, temp[6]);
    Ciphertext temp5_7 = temp[5];
    evaluator.add_inplace(temp5_7, temp[7]);
    Ciphertext temp6_7 = temp[6];
    evaluator.add_inplace(temp6_7, temp[7]);
    Ciphertext temp4_5_6 = temp4_5;
    evaluator.add_inplace(temp4_5_6, temp[6]);
    Ciphertext temp4_5_7 = temp4_5;
    evaluator.add_inplace(temp4_5_7, temp[7]);
    Ciphertext temp4_6_7 = temp4_6;
    evaluator.add_inplace(temp4_6_7, temp[7]);
    Ciphertext temp5_6_7 = temp5_6;
    evaluator.add_inplace(temp5_6_7, temp[7]);
    Ciphertext temp4_5_6_7 = temp4_5_6;
    evaluator.add_inplace(temp4_5_6_7, temp[7]);
    Ciphertext temp8_9 = temp[8];
    evaluator.add_inplace(temp8_9, temp[9]);
    Ciphertext temp8_10 = temp[8];
    evaluator.add_inplace(temp8_10, temp[10]);
    Ciphertext temp8_11 = temp[8];
    evaluator.add_inplace(temp8_11, temp[11]);
    Ciphertext temp9_10 = temp[9];
    evaluator.add_inplace(temp9_10, temp[10]);
    Ciphertext temp9_11 = temp[9];
    evaluator.add_inplace(temp9_11, temp[11]);
    Ciphertext temp10_11 = temp[10];
    evaluator.add_inplace(temp10_11, temp[11]);
    Ciphertext temp8_9_10 = temp8_9;
    evaluator.add_inplace(temp8_9_10, temp[10]);
    Ciphertext temp8_9_11 = temp8_9;
    evaluator.add_inplace(temp8_9_11, temp[11]);
    Ciphertext temp8_10_11 = temp8_10;
    evaluator.add_inplace(temp8_10_11, temp[11]);
    Ciphertext temp9_10_11 = temp9_10;
    evaluator.add_inplace(temp9_10_11, temp[11]);
    Ciphertext temp8_9_10_11 = temp8_9_10;
    evaluator.add_inplace(temp8_9_10_11, temp[11]);
    Ciphertext temp12_13 = temp[12];
    evaluator.add_inplace(temp12_13, temp[13]);
    Ciphertext temp12_14 = temp[12];
    evaluator.add_inplace(temp12_14, temp[14]);
    Ciphertext temp12_15 = temp[12];
    evaluator.add_inplace(temp12_15, temp[15]);
    Ciphertext temp13_14 = temp[13];
    evaluator.add_inplace(temp13_14, temp[14]);
    Ciphertext temp13_15 = temp[13];
    evaluator.add_inplace(temp13_15, temp[15]);
    Ciphertext temp14_15 = temp[14];
    evaluator.add_inplace(temp14_15, temp[15]);
    Ciphertext temp12_13_14 = temp12_13;
    evaluator.add_inplace(temp12_13_14, temp[14]);
    Ciphertext temp12_13_15 = temp12_13;
    evaluator.add_inplace(temp12_13_15, temp[15]);
    Ciphertext temp12_14_15 = temp12_14;
    evaluator.add_inplace(temp12_14_15, temp[15]);
    Ciphertext temp13_14_15 = temp13_14;
    evaluator.add_inplace(temp13_14_15, temp[15]);
    Ciphertext temp12_13_14_15 = temp12_13_14;
    evaluator.add_inplace(temp12_13_14_15, temp[15]);
    Ciphertext temp16_17 = temp[16];
    evaluator.add_inplace(temp16_17, temp[17]);
    Ciphertext temp16_18 = temp[16];
    evaluator.add_inplace(temp16_18, temp[18]);
    Ciphertext temp16_19 = temp[16];
    evaluator.add_inplace(temp16_19, temp[19]);
    Ciphertext temp17_18 = temp[17];
    evaluator.add_inplace(temp17_18, temp[18]);
    Ciphertext temp17_19 = temp[17];
    evaluator.add_inplace(temp17_19, temp[19]);
    Ciphertext temp18_19 = temp[18];
    evaluator.add_inplace(temp18_19, temp[19]);
    Ciphertext temp16_17_18 = temp16_17;
    evaluator.add_inplace(temp16_17_18, temp[18]);
    Ciphertext temp16_17_19 = temp16_17;
    evaluator.add_inplace(temp16_17_19, temp[19]);
    Ciphertext temp16_18_19 = temp16_18;
    evaluator.add_inplace(temp16_18_19, temp[19]);
    Ciphertext temp17_18_19 = temp17_18;
    evaluator.add_inplace(temp17_18_19, temp[19]);
    Ciphertext temp16_17_18_19 = temp16_17_18;
    evaluator.add_inplace(temp16_17_18_19, temp[19]);
    Ciphertext temp20_21 = temp[20];
    evaluator.add_inplace(temp20_21, temp[21]);
    Ciphertext temp20_22 = temp[20];
    evaluator.add_inplace(temp20_22, temp[22]);
    Ciphertext temp20_23 = temp[20];
    evaluator.add_inplace(temp20_23, temp[23]);
    Ciphertext temp21_22 = temp[21];
    evaluator.add_inplace(temp21_22, temp[22]);
    Ciphertext temp21_23 = temp[21];
    evaluator.add_inplace(temp21_23, temp[23]);
    Ciphertext temp22_23 = temp[22];
    evaluator.add_inplace(temp22_23, temp[23]);
    Ciphertext temp20_21_22 = temp20_21;
    evaluator.add_inplace(temp20_21_22, temp[22]);
    Ciphertext temp20_21_23 = temp20_21;
    evaluator.add_inplace(temp20_21_23, temp[23]);
    Ciphertext temp20_22_23 = temp20_22;
    evaluator.add_inplace(temp20_22_23, temp[23]);
    Ciphertext temp21_22_23 = temp21_22;
    evaluator.add_inplace(temp21_22_23, temp[23]);
    Ciphertext temp20_21_22_23 = temp20_21_22;
    evaluator.add_inplace(temp20_21_22_23, temp[23]);
    Ciphertext temp24_25 = temp[24];
    evaluator.add_inplace(temp24_25, temp[25]);
    Ciphertext temp24_26 = temp[24];
    evaluator.add_inplace(temp24_26, temp[26]);
    Ciphertext temp24_27 = temp[24];
    evaluator.add_inplace(temp24_27, temp[27]);
    Ciphertext temp25_26 = temp[25];
    evaluator.add_inplace(temp25_26, temp[26]);
    Ciphertext temp25_27 = temp[25];
    evaluator.add_inplace(temp25_27, temp[27]);
    Ciphertext temp26_27 = temp[26];
    evaluator.add_inplace(temp26_27, temp[27]);
    Ciphertext temp24_25_26 = temp24_25;
    evaluator.add_inplace(temp24_25_26, temp[26]);
    Ciphertext temp24_25_27 = temp24_25;
    evaluator.add_inplace(temp24_25_27, temp[27]);
    Ciphertext temp24_26_27 = temp24_26;
    evaluator.add_inplace(temp24_26_27, temp[27]);
    Ciphertext temp25_26_27 = temp25_26;
    evaluator.add_inplace(temp25_26_27, temp[27]);
    Ciphertext temp24_25_26_27 = temp24_25_26;
    evaluator.add_inplace(temp24_25_26_27, temp[27]);
    Ciphertext temp28_29 = temp[28];
    evaluator.add_inplace(temp28_29, temp[29]);
    Ciphertext temp28_30 = temp[28];
    evaluator.add_inplace(temp28_30, temp[30]);
    Ciphertext temp28_31 = temp[28];
    evaluator.add_inplace(temp28_31, temp[31]);
    Ciphertext temp29_30 = temp[29];
    evaluator.add_inplace(temp29_30, temp[30]);
    Ciphertext temp29_31 = temp[29];
    evaluator.add_inplace(temp29_31, temp[31]);
    Ciphertext temp30_31 = temp[30];
    evaluator.add_inplace(temp30_31, temp[31]);
    Ciphertext temp28_29_30 = temp28_29;
    evaluator.add_inplace(temp28_29_30, temp[30]);
    Ciphertext temp28_29_31 = temp28_29;
    evaluator.add_inplace(temp28_29_31, temp[31]);
    Ciphertext temp28_30_31 = temp28_30;
    evaluator.add_inplace(temp28_30_31, temp[31]);
    Ciphertext temp29_30_31 = temp29_30;
    evaluator.add_inplace(temp29_30_31, temp[31]);
    Ciphertext temp28_29_30_31 = temp28_29_30;
    evaluator.add_inplace(temp28_29_30_31, temp[31]);
    Ciphertext temp32_33 = temp[32];
    evaluator.add_inplace(temp32_33, temp[33]);
    Ciphertext temp32_34 = temp[32];
    evaluator.add_inplace(temp32_34, temp[34]);
    Ciphertext temp32_35 = temp[32];
    evaluator.add_inplace(temp32_35, temp[35]);
    Ciphertext temp33_34 = temp[33];
    evaluator.add_inplace(temp33_34, temp[34]);
    Ciphertext temp33_35 = temp[33];
    evaluator.add_inplace(temp33_35, temp[35]);
    Ciphertext temp34_35 = temp[34];
    evaluator.add_inplace(temp34_35, temp[35]);
    Ciphertext temp32_33_34 = temp32_33;
    evaluator.add_inplace(temp32_33_34, temp[34]);
    Ciphertext temp32_33_35 = temp32_33;
    evaluator.add_inplace(temp32_33_35, temp[35]);
    Ciphertext temp32_34_35 = temp32_34;
    evaluator.add_inplace(temp32_34_35, temp[35]);
    Ciphertext temp33_34_35 = temp33_34;
    evaluator.add_inplace(temp33_34_35, temp[35]);
    Ciphertext temp32_33_34_35 = temp32_33_34;
    evaluator.add_inplace(temp32_33_34_35, temp[35]);

    evaluator.add_inplace(eData[0], temp1_3);
    evaluator.add_inplace(eData[0], temp4_5_6_7);
    evaluator.add_inplace(eData[0], temp8_11);
    evaluator.add_inplace(eData[0], temp14_15);
    evaluator.add_inplace(eData[0], temp16_17_19);
    evaluator.add_inplace(eData[0], temp20_21_22);
    evaluator.add_inplace(eData[0], temp24_25);
    evaluator.add_inplace(eData[0], temp29_30_31);
    evaluator.add_inplace(eData[0], temp33_34_35);
    evaluator.add_inplace(eData[1], temp0_2_3);
    evaluator.add_inplace(eData[1], temp4_6);
    evaluator.add_inplace(eData[1], temp8_10);
    evaluator.add_inplace(eData[1], temp12_13_15);
    evaluator.add_inplace(eData[1], temp17_18);
    evaluator.add_inplace(eData[1], temp20_21_22_23);
    evaluator.add_inplace(eData[1], temp24_25_26);
    evaluator.add_inplace(eData[1], temp28_31);
    evaluator.add_inplace(eData[1], temp32_33_34);
    eData[2] = temp[1];
    evaluator.add_inplace(eData[2], temp4_5_7);
    evaluator.add_inplace(eData[2], temp8_9_10);
    evaluator.add_inplace(eData[2], temp12_14);
    evaluator.add_inplace(eData[2], temp16_17_18_19);
    evaluator.add_inplace(eData[2], temp20_21_23);
    evaluator.add_inplace(eData[2], temp25_26_27);
    evaluator.add_inplace(eData[2], temp28_29_30_31);
    evaluator.add_inplace(eData[2], temp32_33_35);
    evaluator.add_inplace(eData[3], temp0_1_2);
    evaluator.add_inplace(eData[3], temp4_6_7);
    evaluator.add_inplace(eData[3], temp8_9_10_11);
    evaluator.add_inplace(eData[3], temp[14]);
    evaluator.add_inplace(eData[3], temp17_18_19);
    evaluator.add_inplace(eData[3], temp20_22_23);
    evaluator.add_inplace(eData[3], temp24_25_27);
    evaluator.add_inplace(eData[3], temp[28]);
    evaluator.add_inplace(eData[3], temp32_33_34);
    evaluator.add_inplace(eData[4], temp0_1_3);
    evaluator.add_inplace(eData[4], temp5_6_7);
    evaluator.add_inplace(eData[4], temp9_11);
    evaluator.add_inplace(eData[4], temp13_15);
    evaluator.add_inplace(eData[4], temp16_18);
    evaluator.add_inplace(eData[4], temp20_21_23);
    evaluator.add_inplace(eData[4], temp24_25_26_27);
    evaluator.add_inplace(eData[4], temp28_29_31);
    evaluator.add_inplace(eData[4], temp34_35);
    eData[5] = temp0_2;
    evaluator.add_inplace(eData[5], temp4_7);
    evaluator.add_inplace(eData[5], temp8_10_11);
    evaluator.add_inplace(eData[5], temp12_13_15);
    evaluator.add_inplace(eData[5], temp17_19);
    evaluator.add_inplace(eData[5], temp20_21_22_23);
    evaluator.add_inplace(eData[5], temp24_26);
    evaluator.add_inplace(eData[5], temp28_29_30_31);
    evaluator.add_inplace(eData[5], temp32_33_34_35);
    evaluator.add_inplace(eData[6], temp0_1_3);
    evaluator.add_inplace(eData[6], temp4_5_7);
    evaluator.add_inplace(eData[6], temp9_10_11);
    evaluator.add_inplace(eData[6], temp12_13_14);
    evaluator.add_inplace(eData[6], temp[17]);
    evaluator.add_inplace(eData[6], temp20_21_22_23);
    evaluator.add_inplace(eData[6], temp25_26_27);
    evaluator.add_inplace(eData[6], temp28_30_31);
    evaluator.add_inplace(eData[6], temp[35]);
    evaluator.add_inplace(eData[7], temp1_2_3);
    evaluator.add_inplace(eData[7], temp4_6);
    evaluator.add_inplace(eData[7], temp8_9_10);
    evaluator.add_inplace(eData[7], temp12_14);
    evaluator.add_inplace(eData[7], temp16_18_19);
    evaluator.add_inplace(eData[7], temp21_23);
    evaluator.add_inplace(eData[7], temp24_26_27);
    evaluator.add_inplace(eData[7], temp28_29_30_31);
    evaluator.add_inplace(eData[7], temp32_34);
    eData[8] = temp0_1_2_3;
    evaluator.add_inplace(eData[8], temp5_7);
    evaluator.add_inplace(eData[8], temp10_11);
    evaluator.add_inplace(eData[8], temp13_14_15);
    evaluator.add_inplace(eData[8], temp16_18);
    evaluator.add_inplace(eData[8], temp20_22_23);
    evaluator.add_inplace(eData[8], temp24_25_26_27);
    evaluator.add_inplace(eData[8], temp29_31);
    evaluator.add_inplace(eData[8], temp32_33_34_35);
    evaluator.add_inplace(eData[9], temp2_3);
    evaluator.add_inplace(eData[9], temp4_6_7);
    evaluator.add_inplace(eData[9], temp8_10);
    evaluator.add_inplace(eData[9], temp12_13_14_15);
    evaluator.add_inplace(eData[9], temp16_17);
    evaluator.add_inplace(eData[9], temp20_23);
    evaluator.add_inplace(eData[9], temp24_25_26);
    evaluator.add_inplace(eData[9], temp28_29_30_31);
    evaluator.add_inplace(eData[9], temp33_34);
    evaluator.add_inplace(eData[10], temp[1]);
    evaluator.add_inplace(eData[10], temp4_5_6_7);
    evaluator.add_inplace(eData[10], temp9_11);
    evaluator.add_inplace(eData[10], temp12_13_15);
    evaluator.add_inplace(eData[10], temp17_19);
    evaluator.add_inplace(eData[10], temp21_22);
    evaluator.add_inplace(eData[10], temp24_26_27);
    evaluator.add_inplace(eData[10], temp29_30_31);
    evaluator.add_inplace(eData[10], temp32_33_34_35);
    eData[11] = temp0_1_2_3;
    evaluator.add_inplace(eData[11], temp4_5_6);
    evaluator.add_inplace(eData[11], temp8_10);
    evaluator.add_inplace(eData[11], temp13_14);
    evaluator.add_inplace(eData[11], temp16_17_18_19);
    evaluator.add_inplace(eData[11], temp21_23);
    evaluator.add_inplace(eData[11], temp25_26_27);
    evaluator.add_inplace(eData[11], temp28_29_30);
    evaluator.add_inplace(eData[11], temp32_34_35);
    evaluator.add_inplace(eData[12], temp0_1);
    evaluator.add_inplace(eData[12], temp5_6_7);
    evaluator.add_inplace(eData[12], temp9_10_11);
    evaluator.add_inplace(eData[12], temp13_15);
    evaluator.add_inplace(eData[12], temp16_17_18_19);
    evaluator.add_inplace(eData[12], temp20_23);
    evaluator.add_inplace(eData[12], temp26_27);
    evaluator.add_inplace(eData[12], temp28_29_31);
    evaluator.add_inplace(eData[12], temp32_33_34);
    evaluator.add_inplace(eData[13], temp0_1_2);
    evaluator.add_inplace(eData[13], temp4_7);
    evaluator.add_inplace(eData[13], temp8_9_10);
    evaluator.add_inplace(eData[13], temp12_14_15);
    evaluator.add_inplace(eData[13], temp16_18);
    evaluator.add_inplace(eData[13], temp20_22);
    evaluator.add_inplace(eData[13], temp24_25_27);
    evaluator.add_inplace(eData[13], temp29_30);
    evaluator.add_inplace(eData[13], temp32_33_34_35);
    eData[14] = temp1_2_3;
    evaluator.add_inplace(eData[14], temp4_5_6_7);
    evaluator.add_inplace(eData[14], temp8_9_11);
    evaluator.add_inplace(eData[14], temp[13]);
    evaluator.add_inplace(eData[14], temp16_17_19);
    evaluator.add_inplace(eData[14], temp20_21_22);
    evaluator.add_inplace(eData[14], temp24_26);
    evaluator.add_inplace(eData[14], temp28_29_30_31);
    evaluator.add_inplace(eData[14], temp32_33_35);
    evaluator.add_inplace(eData[15], temp0_1_3);
    evaluator.add_inplace(eData[15], temp[4]);
    evaluator.add_inplace(eData[15], temp8_9_10);
    evaluator.add_inplace(eData[15], temp12_13_14);
    evaluator.add_inplace(eData[15], temp16_18_19);
    evaluator.add_inplace(eData[15], temp20_21_22_23);
    evaluator.add_inplace(eData[15], temp[26]);
    evaluator.add_inplace(eData[15], temp29_30_31);
    evaluator.add_inplace(eData[15], temp32_34_35);
    evaluator.add_inplace(eData[16], temp0_1_2_3);
    evaluator.add_inplace(eData[16], temp4_5_7);
    evaluator.add_inplace(eData[16], temp10_11);
    evaluator.add_inplace(eData[16], temp12_13_15);
    evaluator.add_inplace(eData[16], temp17_18_19);
    evaluator.add_inplace(eData[16], temp21_23);
    evaluator.add_inplace(eData[16], temp25_27);
    evaluator.add_inplace(eData[16], temp28_30);
    evaluator.add_inplace(eData[16], temp32_33_35);
    eData[17] = temp0_2;
    evaluator.add_inplace(eData[17], temp4_5_6_7);
    evaluator.add_inplace(eData[17], temp8_9_10_11);
    evaluator.add_inplace(eData[17], temp12_14);
    evaluator.add_inplace(eData[17], temp16_19);
    evaluator.add_inplace(eData[17], temp20_22_23);
    evaluator.add_inplace(eData[17], temp24_25_27);
    evaluator.add_inplace(eData[17], temp29_31);
    evaluator.add_inplace(eData[17], temp32_33_34_35);
    evaluator.add_inplace(eData[18], temp1_2_3);
    evaluator.add_inplace(eData[18], temp4_6_7);
    evaluator.add_inplace(eData[18], temp[11]);
    evaluator.add_inplace(eData[18], temp12_13_15);
    evaluator.add_inplace(eData[18], temp16_17_19);
    evaluator.add_inplace(eData[18], temp21_22_23);
    evaluator.add_inplace(eData[18], temp24_25_26);
    evaluator.add_inplace(eData[18], temp[29]);
    evaluator.add_inplace(eData[18], temp32_33_34_35);
    evaluator.add_inplace(eData[19], temp0_2_3);
    evaluator.add_inplace(eData[19], temp4_5_6_7);
    evaluator.add_inplace(eData[19], temp8_10);
    evaluator.add_inplace(eData[19], temp13_14_15);
    evaluator.add_inplace(eData[19], temp16_18);
    evaluator.add_inplace(eData[19], temp20_21_22);
    evaluator.add_inplace(eData[19], temp24_26);
    evaluator.add_inplace(eData[19], temp28_30_31);
    evaluator.add_inplace(eData[19], temp33_35);
    eData[20] = temp0_1_2_3;
    evaluator.add_inplace(eData[20], temp5_7);
    evaluator.add_inplace(eData[20], temp8_9_10_11);
    evaluator.add_inplace(eData[20], temp12_13_14_15);
    evaluator.add_inplace(eData[20], temp17_19);
    evaluator.add_inplace(eData[20], temp22_23);
    evaluator.add_inplace(eData[20], temp25_26_27);
    evaluator.add_inplace(eData[20], temp28_30);
    evaluator.add_inplace(eData[20], temp32_34_35);
    evaluator.add_inplace(eData[21], temp0_1_2);
    evaluator.add_inplace(eData[21], temp4_5_6_7);
    evaluator.add_inplace(eData[21], temp9_10);
    evaluator.add_inplace(eData[21], temp14_15);
    evaluator.add_inplace(eData[21], temp16_18_19);
    evaluator.add_inplace(eData[21], temp20_22);
    evaluator.add_inplace(eData[21], temp24_25_26_27);
    evaluator.add_inplace(eData[21], temp28_29);
    evaluator.add_inplace(eData[21], temp32_35);
    evaluator.add_inplace(eData[22], temp0_2_3);
    evaluator.add_inplace(eData[22], temp5_6_7);
    evaluator.add_inplace(eData[22], temp8_9_10_11);
    evaluator.add_inplace(eData[22], temp[13]);
    evaluator.add_inplace(eData[22], temp16_17_18_19);
    evaluator.add_inplace(eData[22], temp21_23);
    evaluator.add_inplace(eData[22], temp24_25_27);
    evaluator.add_inplace(eData[22], temp29_31);
    evaluator.add_inplace(eData[22], temp33_34);
    eData[23] = temp1_2_3;
    evaluator.add_inplace(eData[23], temp4_5_6);
    evaluator.add_inplace(eData[23], temp8_10_11);
    evaluator.add_inplace(eData[23], temp12_13_14_15);
    evaluator.add_inplace(eData[23], temp16_17_18);
    evaluator.add_inplace(eData[23], temp20_22);
    evaluator.add_inplace(eData[23], temp25_26);
    evaluator.add_inplace(eData[23], temp28_29_30_31);
    evaluator.add_inplace(eData[23], temp33_35);
    evaluator.add_inplace(eData[24], temp2_3);
    evaluator.add_inplace(eData[24], temp4_5_7);
    evaluator.add_inplace(eData[24], temp8_9_10);
    evaluator.add_inplace(eData[24], temp12_13);
    evaluator.add_inplace(eData[24], temp17_18_19);
    evaluator.add_inplace(eData[24], temp21_22_23);
    evaluator.add_inplace(eData[24], temp25_27);
    evaluator.add_inplace(eData[24], temp28_29_30_31);
    evaluator.add_inplace(eData[24], temp32_35);
    evaluator.add_inplace(eData[25], temp0_1_3);
    evaluator.add_inplace(eData[25], temp5_6);
    evaluator.add_inplace(eData[25], temp8_9_10_11);
    evaluator.add_inplace(eData[25], temp12_13_14);
    evaluator.add_inplace(eData[25], temp16_19);
    evaluator.add_inplace(eData[25], temp20_21_22);
    evaluator.add_inplace(eData[25], temp24_26_27);
    evaluator.add_inplace(eData[25], temp28_30);
    evaluator.add_inplace(eData[25], temp32_34);
    eData[26] = temp0_2;
    evaluator.add_inplace(eData[26], temp4_5_6_7);
    evaluator.add_inplace(eData[26], temp8_9_11);
    evaluator.add_inplace(eData[26], temp13_14_15);
    evaluator.add_inplace(eData[26], temp16_17_18_19);
    evaluator.add_inplace(eData[26], temp20_21_23);
    evaluator.add_inplace(eData[26], temp[25]);
    evaluator.add_inplace(eData[26], temp28_29_31);
    evaluator.add_inplace(eData[26], temp32_33_34);
    evaluator.add_inplace(eData[27], temp[2]);
    evaluator.add_inplace(eData[27], temp5_6_7);
    evaluator.add_inplace(eData[27], temp8_10_11);
    evaluator.add_inplace(eData[27], temp12_13_15);
    evaluator.add_inplace(eData[27], temp[16]);
    evaluator.add_inplace(eData[27], temp20_21_22);
    evaluator.add_inplace(eData[27], temp24_25_26);
    evaluator.add_inplace(eData[27], temp28_30_31);
    evaluator.add_inplace(eData[27], temp32_33_34_35);
    evaluator.add_inplace(eData[28], temp1_3);
    evaluator.add_inplace(eData[28], temp4_6);
    evaluator.add_inplace(eData[28], temp8_9_11);
    evaluator.add_inplace(eData[28], temp12_13_14_15);
    evaluator.add_inplace(eData[28], temp16_17_19);
    evaluator.add_inplace(eData[28], temp22_23);
    evaluator.add_inplace(eData[28], temp24_25_27);
    evaluator.add_inplace(eData[28], temp29_30_31);
    evaluator.add_inplace(eData[28], temp33_35);
    eData[29] = temp0_1_3;
    evaluator.add_inplace(eData[29], temp5_7);
    evaluator.add_inplace(eData[29], temp8_9_10_11);
    evaluator.add_inplace(eData[29], temp12_14);
    evaluator.add_inplace(eData[29], temp16_17_18_19);
    evaluator.add_inplace(eData[29], temp20_21_22_23);
    evaluator.add_inplace(eData[29], temp24_26);
    evaluator.add_inplace(eData[29], temp28_31);
    evaluator.add_inplace(eData[29], temp32_34_35);
    evaluator.add_inplace(eData[30], temp0_1_2);
    evaluator.add_inplace(eData[30], temp[5]);
    evaluator.add_inplace(eData[30], temp8_9_10_11);
    evaluator.add_inplace(eData[30], temp13_14_15);
    evaluator.add_inplace(eData[30], temp16_18_19);
    evaluator.add_inplace(eData[30], temp[23]);
    evaluator.add_inplace(eData[30], temp24_25_27);
    evaluator.add_inplace(eData[30], temp28_29_31);
    evaluator.add_inplace(eData[30], temp33_34_35);
    evaluator.add_inplace(eData[31], temp0_2);
    evaluator.add_inplace(eData[31], temp4_6_7);
    evaluator.add_inplace(eData[31], temp9_11);
    evaluator.add_inplace(eData[31], temp12_14_15);
    evaluator.add_inplace(eData[31], temp16_17_18_19);
    evaluator.add_inplace(eData[31], temp20_22);
    evaluator.add_inplace(eData[31], temp25_26_27);
    evaluator.add_inplace(eData[31], temp28_30);
    evaluator.add_inplace(eData[31], temp32_33_34);
    eData[32] = temp1_2_3;
    evaluator.add_inplace(eData[32], temp4_6);
    evaluator.add_inplace(eData[32], temp8_10_11);
    evaluator.add_inplace(eData[32], temp12_13_14_15);
    evaluator.add_inplace(eData[32], temp17_19);
    evaluator.add_inplace(eData[32], temp20_21_22_23);
    evaluator.add_inplace(eData[32], temp24_25_26_27);
    evaluator.add_inplace(eData[32], temp29_31);
    evaluator.add_inplace(eData[32], temp34_35);
    evaluator.add_inplace(eData[33], temp0_1_2_3);
    evaluator.add_inplace(eData[33], temp4_5);
    evaluator.add_inplace(eData[33], temp8_11);
    evaluator.add_inplace(eData[33], temp12_13_14);
    evaluator.add_inplace(eData[33], temp16_17_18_19);
    evaluator.add_inplace(eData[33], temp21_22);
    evaluator.add_inplace(eData[33], temp26_27);
    evaluator.add_inplace(eData[33], temp28_30_31);
    evaluator.add_inplace(eData[33], temp32_34);
    evaluator.add_inplace(eData[34], temp0_1_3);
    evaluator.add_inplace(eData[34], temp5_7);
    evaluator.add_inplace(eData[34], temp9_10);
    evaluator.add_inplace(eData[34], temp12_14_15);
    evaluator.add_inplace(eData[34], temp17_18_19);
    evaluator.add_inplace(eData[34], temp20_21_22_23);
    evaluator.add_inplace(eData[34], temp[25]);
    evaluator.add_inplace(eData[34], temp28_29_30_31);
    evaluator.add_inplace(eData[34], temp33_35);
    eData[35] = temp1_2;
    evaluator.add_inplace(eData[35], temp4_5_6_7);
    evaluator.add_inplace(eData[35], temp9_11);
    evaluator.add_inplace(eData[35], temp13_14_15);
    evaluator.add_inplace(eData[35], temp16_17_18);
    evaluator.add_inplace(eData[35], temp20_22_23);
    evaluator.add_inplace(eData[35], temp24_25_26_27);
    evaluator.add_inplace(eData[35], temp28_29_30);
    evaluator.add_inplace(eData[35], temp32_34);
}
// Compute the box,(x0,x1,x2)——>(x0,x0*x2+x1,-x0*x1+x0*x2+x2)
void HE_Sbox(vector<Ciphertext> &eData, Evaluator &evaluator, RelinKeys &relin_keys)
{
    // (x0,x1,x2)——> (x0,x0*x2+x1,-x0*x1+x0*x2+x2)
    Ciphertext c01 = eData[1];
    Ciphertext c02 = eData[2];
    evaluator.multiply_inplace(c01, eData[0]);
    evaluator.relinearize_inplace(c01, relin_keys);
    // c01*=eData[0];
    evaluator.multiply_inplace(c02, eData[0]);
    evaluator.relinearize_inplace(c02, relin_keys);
    // c02*=eData[0];

    evaluator.add_inplace(eData[1], c02);
    evaluator.sub_inplace(eData[2], c01);
    evaluator.add_inplace(eData[2], c02);

    for (long j = 3; j < BlockWords; j += 3)
    {
        c01 = eData[j + 1];
        evaluator.multiply_inplace(c01, eData[j]);
        evaluator.relinearize_inplace(c01, relin_keys);

        c02 = eData[j + 2];
        evaluator.multiply_inplace(c02, eData[j]);
        evaluator.relinearize_inplace(c02, relin_keys);

        evaluator.add_inplace(eData[j + 1], c02);
        evaluator.sub_inplace(eData[j + 2], c01);
        evaluator.add_inplace(eData[j + 2], c02);
    }
}
// Add the round key to the encrypted data
void HE_Add(vector<Ciphertext> &encryptedKeyStream, vector<vector<long>> &Xset, vector<Ciphertext> &encryptedSymKey, Evaluator &evaluator, BatchEncoder &batch_encoder)
{
    Plaintext encodedXseti;
    Ciphertext encryptedRoundKeySeti;
    for (long j = 0; j < BlockWords; j++)
    {
        batch_encoder.encode(Xset[j], encodedXseti);
        encryptedRoundKeySeti = encryptedSymKey[j];
        evaluator.multiply_plain_inplace(encryptedRoundKeySeti, encodedXseti);
        evaluator.add_inplace(encryptedKeyStream[j], encryptedRoundKeySeti);
    }
}
int main()
{
    std::cout << "Nr: " << Nr << std::endl;
    std::cout << "BlockWord: " << BlockWords << std::endl;
    std::cout << "BlockPlainWord: " << BlockPlainWords << std::endl;
    std::cout << "PlainMod: " << PlainMod << std::endl;
    std::cout << "PlainBlock: " << PlainBlock << std::endl;
    std::cout << "nslots: " << nslots << std::endl;
    //======================= client offline ===========================
    // initial vector
    vector<long> IV(BlockWords);
    for (unsigned i = 0; i < BlockWords; i++)
    {
        IV[i] = i + 1;
    }

    // generate symkey
    random_device rd;
    vector<long> SymKey(BlockWords);
    for (unsigned i = 0; i < BlockWords; i++)
    {
        SymKey[i] = rd() % PlainMod;
    }
    std::cout << "SymKey generated." << std::endl;

    // Generating Public Key and encrypting the symmetric key
    auto start = std::chrono::high_resolution_clock::now();
    EncryptionParameters parms(scheme_type::bfv);
    long poly_modulus_degree = phi_m;
    parms.set_poly_modulus_degree(poly_modulus_degree);

    int SecLevel = 128;
    vector<int> bit_sizes;
    set_params(poly_modulus_degree, SecLevel, bit_sizes);
    parms.set_coeff_modulus(CoeffModulus::Create(poly_modulus_degree, bit_sizes));
    // parms.set_coeff_modulus(CoeffModulus::BFVDefault(poly_modulus_degree));
    parms.set_plain_modulus(PlainMod);
    SEALContext context(parms, true, sec_level_type::none);
    if (SecLevel == 128)
    {
        context = SEALContext(parms, true, sec_level_type::tc128);
    }
    if (SecLevel == 192)
    {
        context = SEALContext(parms, true, sec_level_type::tc192);
    }
    if (SecLevel == 256)
    {
        context = SEALContext(parms, true, sec_level_type::tc256);
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_seconds_context = end - start;
    std::cout << "Context generation time: " << elapsed_seconds_context.count() << "s\n";
    print_parameters(context);

    auto start_PubKey = std::chrono::high_resolution_clock::now();
    KeyGenerator keygen(context);
    SecretKey secret_key = keygen.secret_key();
    PublicKey public_key;
    keygen.create_public_key(public_key);
    RelinKeys relin_keys;
    keygen.create_relin_keys(relin_keys);
    Encryptor encryptor(context, public_key);
    Evaluator evaluator(context);
    Decryptor decryptor(context, secret_key);
    auto end_PubKey = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_seconds_PubKey = end_PubKey - start_PubKey;
    std::cout << "PublicKey generation time: " << elapsed_seconds_PubKey.count() << "s\n";

    BatchEncoder batch_encoder(context);

    long nslots = batch_encoder.slot_count();

    auto &plain_modulus = parms.plain_modulus();

    long Qbits = context.key_context_data()->total_coeff_modulus_bit_count();

    auto start_keyEncryption = std::chrono::high_resolution_clock::now();
    vector<Ciphertext> encryptedSymKey(BlockWords);
    encryptSymKey(encryptedSymKey, SymKey, batch_encoder, encryptor, nslots);
    auto end_keyEncryption = std::chrono::high_resolution_clock::now();
    double keyEncryption = std::chrono::duration<double>(end_keyEncryption - start_keyEncryption).count();
    std::cout << "SymKey FHE time: " << keyEncryption << "s\n";

    for (int test = 0; test < 10; test++)
    {
        std::cout << "--------------- Test = " << test << "---------------" << std::endl;
        // Generating key stream
        std::vector<long> NonceSet(PlainBlock);
        std::vector<long> KeyStream(PlainWords);
        std::vector<long> RoundKey(BlockWords);
        long nonce;
        long block_num;
        std::vector<long> state(BlockWords);
        Keccak_HashInstance shake128_2;
        std::cout << "Generating KeyStream..." << std::endl;
        auto start_keyStream = std::chrono::high_resolution_clock::now();
        uint64_t start_cycle1 = rdtsc();
        for (long counter = counter_begin; counter <= counter_end; counter++)
        {
            nonce = generate_secure_random_int(NonceSize);
            random_init_shake(nonce, counter, shake128_2);
            block_num = counter - counter_begin;
            NonceSet[block_num] = nonce;
            for (unsigned r = 0; r <= Nr; r++)
            {
                for (unsigned i = 0; i < BlockWords; ++i)
                {
                    RoundKey[i] = (SymKey[i] * generate_random_field_element(shake128_2, false, max_prime_size, PlainMod)) % PlainMod;
                }
                if (r == 0)
                {
                    for (unsigned i = 0; i < BlockWords; i++)
                    {
                        state[i] = (RoundKey[i] + IV[i]) % PlainMod;
                    }
                }
                else if (r < Nr)
                {
                    yusP.M36(state);  // Linear
                    yusP.Sbox(state); // Sbox
                    for (unsigned i = 0; i < BlockWords; i++)
                    {
                        state[i] = (state[i] + RoundKey[i]) % PlainMod;
                    }
                }
                else
                {                     // last round
                    yusP.M36(state);  // Linear
                    yusP.Sbox(state); // Sbox
                    for (unsigned i = 0; i < BlockWords; i++)
                    {
                        state[i] = (state[i] + RoundKey[i]) % PlainMod;
                    }
                    yusP.M36(state); // Linear
                    memcpy(&KeyStream[(block_num)*BlockPlainWords], state.data(), BlockPlainWords * sizeof(long));
                }
            }
        }
        uint64_t end_cycle1 = rdtsc();
        auto end_keyStream = std::chrono::high_resolution_clock::now();
        double Client_offtime = std::chrono::duration_cast<std::chrono::duration<double>>(end_keyStream - start_keyStream).count();
        std::cout << "Encryption offline total time: " << Client_offtime << "s\n";
        uint64_t cycle_count1 = end_cycle1 - start_cycle1;
        std::cout << "Encryption offline total cycles: " << cycle_count1 << std::endl;

        state.clear();
        RoundKey.clear();
        Keccak_HashFinal(&shake128_2, nullptr);

        // if (!writeEncryptedSymKey(encryptedSymKey, "Client_encryptedSymKey.bin"))
        // {
        //     return false;
        // }
        // std::cout << "Client_encryptedSymKey.bin has been written to file." << std::endl;

        // v======================== server offline ===========================
        vector<Plaintext> encodedIV(BlockWords);
        for (int i = 0; i < BlockWords; i++)
        {
            vector<long> IVi(nslots, IV[i]);
            batch_encoder.encode(IVi, encodedIV[i]);
        }
        std::cout << "Generating XOF stream..." << std::endl;
        std::vector<vector<long>> Xset(NrBlockWords, vector<long>(nslots, 0));
        long rB;
        Keccak_HashInstance shake128_3;
        auto start_XOF = std::chrono::high_resolution_clock::now();
        for (long counter = counter_begin; counter <= counter_end; counter++)
        {
            block_num = counter - counter_begin;
            nonce = NonceSet[block_num];
            random_init_shake(nonce, counter, shake128_3);
            for (unsigned r = 0; r <= Nr; r++)
            {
                rB = r * BlockWords;
                for (unsigned i = 0; i < BlockWords; ++i)
                {
                    Xset[rB + i][block_num] = generate_random_field_element(shake128_3, false, max_prime_size, PlainMod);
                }
            }
        }
        auto end_XOF = std::chrono::high_resolution_clock::now();
        double XOF_time = std::chrono::duration<double>(end_XOF - start_XOF).count();
        std::cout << "XOF stream Generation time: " << XOF_time << "s\n";
        NonceSet.clear();
        Keccak_HashFinal(&shake128_3, nullptr);

        int noise_budget = min_noise_budget(encryptedSymKey, decryptor);
        std::cout << "noise budget initially: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }

        double Sbox_time = 0, Linear_time = 0, Add_time = 0;
        auto start_sbox = std::chrono::high_resolution_clock::now();
        auto end_sbox = std::chrono::high_resolution_clock::now();
        auto start_linear = std::chrono::high_resolution_clock::now();
        auto end_linear = std::chrono::high_resolution_clock::now();
        auto start_add = std::chrono::high_resolution_clock::now();
        auto end_add = std::chrono::high_resolution_clock::now();
        vector<double> sbox_set(Nr);
        vector<double> linear_set(Nr + 1);
        vector<Ciphertext> encryptedKeyStream = encryptedSymKey;
        std::cout << "whiteround start" << std::endl;
        Plaintext encodedXseti;
        start_add = std::chrono::high_resolution_clock::now();
        for (long i = 0; i < BlockWords; i++)
        { // encrypt the encoded key
            batch_encoder.encode(Xset[i], encodedXseti);
            evaluator.multiply_plain_inplace(encryptedKeyStream[i], encodedXseti);
            evaluator.add_plain_inplace(encryptedKeyStream[i], encodedIV[i]);
        }
        end_add = std::chrono::high_resolution_clock::now();
        Add_time += std::chrono::duration<double>(end_add - start_add).count();
        std::cout << "whiteround time: " << Add_time << "s\n";
        Xset.erase(Xset.begin(), Xset.begin() + BlockWords);
        encodedIV.clear();
        encodedXseti.release();

        noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
        std::cout << "noise budget after Whiteround: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }

        for (long r = 1; r < Nr; r++)
        {
            std::cout << "Round " << r << " start" << std::endl;
            start_linear = std::chrono::high_resolution_clock::now();
            // Linear Layer
            HE_M(encryptedKeyStream, evaluator);
            end_linear = std::chrono::high_resolution_clock::now();
            Linear_time += std::chrono::duration<double>(end_linear - start_linear).count();
            linear_set[r - 1] = std::chrono::duration<double>(end_linear - start_linear).count();
            noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
            std::cout << "noise budget after linear: " << noise_budget << std::endl;
            if (noise_budget <= 0)
            {
                std::cerr << "noise budget is not enough!!!" << std::endl;
                continue;
            }
            start_sbox = std::chrono::high_resolution_clock::now();
            // S Layer
            HE_Sbox(encryptedKeyStream, evaluator, relin_keys);
            end_sbox = std::chrono::high_resolution_clock::now();
            Sbox_time += std::chrono::duration<double>(end_sbox - start_sbox).count();
            sbox_set[r - 1] = std::chrono::duration<double>(end_sbox - start_sbox).count();
            noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
            std::cout << "noise budget after sbox: " << noise_budget << std::endl;
            if (noise_budget <= 0)
            {
                std::cerr << "noise budget is not enough!!!" << std::endl;
                continue;
            }
            // Round Key Addition
            start_add = std::chrono::high_resolution_clock::now();
            HE_Add(encryptedKeyStream, Xset, encryptedSymKey, evaluator, batch_encoder);
            end_add = std::chrono::high_resolution_clock::now();
            Add_time += std::chrono::duration<double>(end_add - start_add).count();
            Xset.erase(Xset.begin(), Xset.begin() + BlockWords);
            noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
            std::cout << "noise budget after Add: " << noise_budget << std::endl;
            if (noise_budget <= 0)
            {
                std::cerr << "noise budget is not enough!!!" << std::endl;
                continue;
            }
        }
        // last round
        std::cout << "the last Round " << Nr << " start" << std::endl;
        start_linear = std::chrono::high_resolution_clock::now();
        // Linear Layer
        HE_M(encryptedKeyStream, evaluator);
        end_linear = std::chrono::high_resolution_clock::now();
        Linear_time += std::chrono::duration<double>(end_linear - start_linear).count();
        linear_set[Nr - 1] = std::chrono::duration<double>(end_linear - start_linear).count();
        noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
        std::cout << "noise budget after linear: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        start_sbox = std::chrono::high_resolution_clock::now();
        // S Layer
        HE_Sbox(encryptedKeyStream, evaluator, relin_keys);
        // HE_Last_Sbox(encryptedKeyStream);
        end_sbox = std::chrono::high_resolution_clock::now();
        Sbox_time += std::chrono::duration<double>(end_sbox - start_sbox).count();
        sbox_set[Nr - 1] = std::chrono::duration<double>(end_sbox - start_sbox).count();
        noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
        std::cout << "noise budget after sbox: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        // add
        start_add = std::chrono::high_resolution_clock::now();
        HE_Add(encryptedKeyStream, Xset, encryptedSymKey, evaluator, batch_encoder);
        end_add = std::chrono::high_resolution_clock::now();
        Add_time += std::chrono::duration<double>(end_add - start_add).count();
        Xset.erase(Xset.begin(), Xset.begin() + BlockWords);

        noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
        std::cout << "noise budget after Add: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        start_linear = std::chrono::high_resolution_clock::now();
        // Linear Layer
        HE_M(encryptedKeyStream, evaluator);
        end_linear = std::chrono::high_resolution_clock::now();
        Linear_time += std::chrono::duration<double>(end_linear - start_linear).count();
        linear_set[Nr] = std::chrono::duration<double>(end_linear - start_linear).count();
        noise_budget = min_noise_budget(encryptedKeyStream, decryptor);
        std::cout << "noise budget after linear: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        // truncation
        encryptedKeyStream.erase(encryptedKeyStream.begin() + BlockPlainWords, encryptedKeyStream.end());
        // XOF_time,Add_time、Sbox_time、Linear_time
        std::cout << "XOF time: " << XOF_time << "s\n";
        std::cout << "Add time: " << Add_time << "s\n";
        std::cout << "Sbox time: " << Sbox_time << "s\n";
        std::cout << "Linear time: " << Linear_time << "s\n";
        // Server_offtime
        double Server_offtime = XOF_time + Add_time + Sbox_time + Linear_time;
        std::cout << "Server offline total time: " << Server_offtime << "s\n";
        std::cout << "sbox_timeset: ";
        for (const auto &time : sbox_set)
        {
            std::cout << time << " ";
        }
        std::cout << endl;
        std::cout << "linear_timeset: ";
        for (const auto &time : linear_set)
        {
            std::cout << time << " ";
        }
        std::cout << endl;

        // ======================== client online =======================
        vector<long> PlainStream(PlainWords);
        for (int i = 0; i < PlainWords; i++)
        {
            PlainStream[i] = rd() % PlainMod;
        }
        vector<vector<long>> CipherStream(BlockPlainWords, vector<long>(nslots, 0));
        long jBP;
        auto start_ClientOnline = std::chrono::high_resolution_clock::now();
        uint64_t start_cycle2 = rdtsc();
        for (int j = 0; j < PlainBlock; j++)
        {
            jBP = j * BlockPlainWords;
            for (int i = 0; i < BlockPlainWords; i++)
            {
                CipherStream[i][j] = (PlainStream[jBP + i] - KeyStream[jBP + i]) % PlainMod;
            }
        }
        uint64_t end_cycle2 = rdtsc();
        auto end_ClientOnline = std::chrono::high_resolution_clock::now();
        uint64_t cycle_count2 = end_cycle2 - start_cycle2;
        uint64_t cycle_count = cycle_count1 + cycle_count2;
        double Client_ontime = std::chrono::duration<double>(end_ClientOnline - start_ClientOnline).count();
        std::cout << "Client onine total time:" << std::chrono::duration<double>(end_ClientOnline - start_ClientOnline).count() << "s\n";
        double Client_totaltime = Client_offtime + Client_ontime;
        std::cout << "Client total time: " << Client_totaltime << "s\n";
        double Cli_throughput = (8 * cycle_count) / Plainbits; // Cycle/Byte
        std::cout << "Client Throughput: " << Cli_throughput << "Cycle/Byte\n";
        // ============================== server online ===========================
        vector<Ciphertext> encryptedPlainStream = encryptedKeyStream;
        encryptedKeyStream.clear();
        Plaintext encodedCipherStreami;
        auto start_ServerOnline = std::chrono::high_resolution_clock::now();
        for (int i = 0; i < BlockPlainWords; i++)
        {
            batch_encoder.encode(CipherStream[i], encodedCipherStreami);
            evaluator.add_plain_inplace(encryptedPlainStream[i], encodedCipherStreami);
        }
        auto end_ServerOnline = std::chrono::high_resolution_clock::now();
        double server_ontime = std::chrono::duration<double>(end_ServerOnline - start_ServerOnline).count();
        std::cout << "Server onine total time:" << server_ontime << "s\n";
        CipherStream.clear();
        encodedCipherStreami.release();

        noise_budget = min_noise_budget(encryptedPlainStream, decryptor);
        std::cout << "noise budget after online: " << noise_budget << std::endl;
        if (noise_budget <= 0)
        {
            std::cerr << "noise budget is not enough!!!" << std::endl;
            continue;
        }
        double Server_totaltime = Server_offtime + server_ontime;
        double Ser_throughput = Plainbits / (pow(2, 13) * Server_totaltime);
        std::cout << "Server total time: " << Server_totaltime << "s\n";
        std::cout << "Server Throughput: " << Ser_throughput << "KiB/s\n";
        std::cout << "Test " << test << " finished." << std::endl;
    }
    return 0;
}
