#ifndef PARAMS_HPP
#define PARAMS_HPP

#include <vector>
#include <iostream>

void set_params(long poly_modulus_degree, int SecLevel, std::vector<int> &bit_sizes)
{
    if (poly_modulus_degree == 16384)
    {
        if (SecLevel == 128)
        {
        bit_sizes = {53, 53, 53, 53, 53, 53, 53, 53};
        // logq = 424, maximum depth = 10
        }
        if (SecLevel == 192)
        {
        bit_sizes = {43,43,43,43,43,43,43};
        }
    }
    if (poly_modulus_degree == 32768)
    {
        if (SecLevel == 128)
        {
           bit_sizes = {55,55,55,55,55,55,55,55,55,55,55,55,55,55,55,56};
        }//55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 55 + 56 = 881
        if (SecLevel == 192){
        bit_sizes = {59, 58, 58, 58, 58, 58, 59, 59, 59, 59};
        // logq = 585, maximum depth = 14
        }
    }
    if (poly_modulus_degree == 65536)
    {
        if (SecLevel == 256){
        bit_sizes = {58, 57, 57, 57, 57, 57, 57, 57, 57, 58, 58, 58, 58, 58, 58, 58};
        // logq = 920, maximum depth = 23
        }
    }
}
#endif
