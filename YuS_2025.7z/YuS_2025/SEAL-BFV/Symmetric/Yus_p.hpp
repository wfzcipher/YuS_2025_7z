#ifndef YUS_P_HPP
#define YUS_P_HPP

#include <cstdint>
#include <iostream>
#include <array>
#include <vector>
#include <cmath>

class YusP
{
public:
    explicit YusP(long plainMod) : PlainMod(plainMod) {}

    void M36(std::vector<long> &data);
    void Sbox(std::vector<long> &data);

private:
    long PlainMod;
};

#endif // YUS_P_HPP